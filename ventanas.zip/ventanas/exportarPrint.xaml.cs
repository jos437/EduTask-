﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using iTextSharp.text;
using iTextSharp.text.pdf;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Windows;
using System.Xml.Linq;
using iTextDocument = iTextSharp.text.Document;
using iTextParagraph = iTextSharp.text.Paragraph;

namespace eduTask.ventanas
{
    public partial class exportarPrint : Window
    {
        private DataService _dataService;

        public exportarPrint()
        {
            InitializeComponent();
            _dataService = new DataService();
            ExcelPackage.License.SetNonCommercialPersonal("Jose");
        }

        private void btnExportar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var configuracion = ObtenerConfiguracionExportacion();

                if (configuracion.Formato == "EXCEL")
                {
                    ExportarAExcel(configuracion);
                }
                else if (configuracion.Formato == "PDF")
                {
                    ExportarAPDF(configuracion);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error durante la exportación: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnVistaPrevia_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var configuracion = ObtenerConfiguracionExportacion();
                MostrarVistaPrevia(configuracion);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en vista previa: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
            menuWindow.Show();
            this.Close();
        }

        private ConfiguracionExportacion ObtenerConfiguracionExportacion()
        {
            return new ConfiguracionExportacion
            {
                ListaSeleccionada = rbListaPadres.IsChecked == true ? "PADRES" :
                                   rbListaTareas.IsChecked == true ? "TAREAS" : "COMPLETA",
                Formato = rbFormatoExcel.IsChecked == true ? "EXCEL" : "PDF",
                IncluirFechas = chkIncluirFechas.IsChecked == true,
                IncluirEstado = chkIncluirEstado.IsChecked == true,
                IncluirTelefonos = chkIncluirTelefonos.IsChecked == true,
                IncluirComentarios = chkIncluirComentarios.IsChecked == true,
                FormatoTabla = chkFormatoTabla.IsChecked == true
            };
        }

        private void ExportarAExcel(ConfiguracionExportacion config)
        {
            var saveDialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "Archivo Excel|*.xlsx",
                FileName = GenerarNombreArchivo(config) + ".xlsx"
            };

            if (saveDialog.ShowDialog() == true)
            {
                using (var package = new ExcelPackage())
                {
                    var worksheet = package.Workbook.Worksheets.Add("Datos Exportados");

                    // Configurar los datos según la lista seleccionada
                    switch (config.ListaSeleccionada)
                    {
                        case "PADRES":
                            ExportarPadresAExcel(worksheet, config);
                            break;
                        case "TAREAS":
                            ExportarTareasAExcel(worksheet, config);
                            break;
                        case "COMPLETA":
                            ExportarListaCompletaAExcel(worksheet, config);
                            break;
                    }

                    // Autoajustar columnas
                    worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                    // Guardar archivo
                    package.SaveAs(new FileInfo(saveDialog.FileName));
                }

                MostrarMensajeExito(saveDialog.FileName, config.Formato);
            }
        }

        private void ExportarPadresAExcel(ExcelWorksheet worksheet, ConfiguracionExportacion config)
        {
            var padres = _dataService.ObtenerTodosLosPadres();
            int row = 1;

            // Encabezados
            worksheet.Cells[row, 1].Value = "ID";
            worksheet.Cells[row, 2].Value = "NOMBRE DEL PADRE";
            worksheet.Cells[row, 3].Value = "ALUMNO";

            int col = 4;
            if (config.IncluirTelefonos)
            {
                worksheet.Cells[row, col].Value = "TELÉFONO";
                col++;
            }

            if (config.IncluirComentarios)
            {
                worksheet.Cells[row, col].Value = "COMENTARIO";
                col++;
            }

            // Estilo encabezados
            using (var range = worksheet.Cells[1, 1, 1, col - 1])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
                range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
            }

            // Datos
            row = 2;
            foreach (var padre in padres)
            {
                worksheet.Cells[row, 1].Value = padre.IdPadre;
                worksheet.Cells[row, 2].Value = padre.Nombre;
                worksheet.Cells[row, 3].Value = padre.Alumno ?? "No especificado";

                col = 4;
                if (config.IncluirTelefonos)
                {
                    worksheet.Cells[row, col].Value = padre.Contacto ?? "No especificado";
                    col++;
                }

                if (config.IncluirComentarios)
                {
                    worksheet.Cells[row, col].Value = padre.Comentario ?? "Sin comentarios";
                    col++;
                }
                row++;
            }

            // Bordes para la tabla si está activado
            if (config.FormatoTabla)
            {
                using (var range = worksheet.Cells[1, 1, row - 1, col - 1])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                }
            }
        }

        private void ExportarTareasAExcel(ExcelWorksheet worksheet, ConfiguracionExportacion config)
        {
            var tareas = _dataService.ObtenerTodasLasTareas();
            int row = 1;

            // Encabezados
            worksheet.Cells[row, 1].Value = "ID TAREA";
            worksheet.Cells[row, 2].Value = "DESCRIPCIÓN";
            worksheet.Cells[row, 3].Value = "VECES ASIGNADA";

            int col = 4;
            if (config.IncluirFechas)
            {
                worksheet.Cells[row, col].Value = "FECHA CREACIÓN";
                col++;
            }

            // Estilo encabezados
            using (var range = worksheet.Cells[1, 1, 1, col - 1])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGreen);
                range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
            }

            // Datos
            row = 2;
            foreach (var tarea in tareas)
            {
                worksheet.Cells[row, 1].Value = tarea.IdTarea;
                worksheet.Cells[row, 2].Value = tarea.Descripcion;
                worksheet.Cells[row, 3].Value = tarea.VecesAsignada;

                col = 4;
                if (config.IncluirFechas)
                {
                    worksheet.Cells[row, col].Value = tarea.FechaCreacion.ToString("dd/MM/yyyy");
                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/mm/yyyy";
                    col++;
                }
                row++;
            }

            if (config.FormatoTabla)
            {
                using (var range = worksheet.Cells[1, 1, row - 1, col - 1])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                }
            }
        }

        private void ExportarListaCompletaAExcel(ExcelWorksheet worksheet, ConfiguracionExportacion config)
        {
            var datos = _dataService.ObtenerPadresConTareas();
            int row = 1;

            // Encabezados
            worksheet.Cells[row, 1].Value = "PADRE";
            worksheet.Cells[row, 2].Value = "ALUMNO";

            int col = 3;
            if (config.IncluirTelefonos)
            {
                worksheet.Cells[row, col].Value = "TELÉFONO";
                col++;
            }

            worksheet.Cells[row, col].Value = "TAREA ACTUAL";
            col++;

            if (config.IncluirEstado)
            {
                worksheet.Cells[row, col].Value = "ESTADO";
                col++;
            }

            if (config.IncluirFechas)
            {
                worksheet.Cells[row, col].Value = "FECHA ASIGNACIÓN";
                col++;
            }

            // Estilo encabezados
            using (var range = worksheet.Cells[1, 1, 1, col - 1])
            {
                range.Style.Font.Bold = true;
                range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightYellow);
                range.Style.Border.BorderAround(ExcelBorderStyle.Thin);
            }

            // Datos
            row = 2;
            foreach (var dato in datos)
            {
                worksheet.Cells[row, 1].Value = dato.NombrePadre;
                worksheet.Cells[row, 2].Value = dato.NombreAlumno;

                col = 3;
                if (config.IncluirTelefonos)
                {
                    worksheet.Cells[row, col].Value = dato.Contacto;
                    col++;
                }

                worksheet.Cells[row, col].Value = dato.TareaActual;
                col++;

                if (config.IncluirEstado)
                {
                    worksheet.Cells[row, col].Value = dato.StatusTarea;

                    // Color condicional para estados
                    var estadoCell = worksheet.Cells[row, col];
                    switch (dato.StatusTarea)
                    {
                        case "Cumplida":
                            estadoCell.Style.Font.Color.SetColor(System.Drawing.Color.Green);
                            break;
                        case "En Proceso":
                            estadoCell.Style.Font.Color.SetColor(System.Drawing.Color.Orange);
                            break;
                        case "Incumplida":
                            estadoCell.Style.Font.Color.SetColor(System.Drawing.Color.Red);
                            break;
                    }
                    col++;
                }

                if (config.IncluirFechas)
                {
                    worksheet.Cells[row, col].Value = dato.FechaAsignacion;
                    worksheet.Cells[row, col].Style.Numberformat.Format = "dd/mm/yyyy";
                    col++;
                }
                row++;
            }

            if (config.FormatoTabla)
            {
                using (var range = worksheet.Cells[1, 1, row - 1, col - 1])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                }
            }
        }

        private void ExportarAPDF(ConfiguracionExportacion config)
        {
            var saveDialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "Archivo PDF|*.pdf",
                FileName = GenerarNombreArchivo(config) + ".pdf"
            };

            if (saveDialog.ShowDialog() == true)
            {
                using (var fs = new FileStream(saveDialog.FileName, FileMode.Create, FileAccess.Write))
                {
                    var document = new iTextDocument(PageSize.A4.Rotate(), 20, 20, 30, 30);
                    var writer = PdfWriter.GetInstance(document, fs);

                    document.Open();

                    // Título del documento
                    var titulo = new iTextParagraph("SISTEMA DE GESTIÓN EDUCATIVA",
                        FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16, BaseColor.DarkGray));
                    titulo.Alignment = Element.ALIGN_CENTER;
                    document.Add(titulo);

                    var subtitulo = new iTextParagraph($"Reporte: {config.ListaSeleccionada} - {DateTime.Now:dd/MM/yyyy HH:mm}",
                        FontFactory.GetFont(FontFactory.HELVETICA, 12, BaseColor.Gray));
                    subtitulo.Alignment = Element.ALIGN_CENTER;
                    document.Add(subtitulo);

                    document.Add(new iTextParagraph(" ")); // Espacio

                    // Contenido según la lista seleccionada
                    switch (config.ListaSeleccionada)
                    {
                        case "PADRES":
                            ExportarPadresAPDF(document, config);
                            break;
                        case "TAREAS":
                            ExportarTareasAPDF(document, config);
                            break;
                        case "COMPLETA":
                            ExportarListaCompletaAPDF(document, config);
                            break;
                    }

                    document.Close();
                }

                MostrarMensajeExito(saveDialog.FileName, config.Formato);
            }
        }

        private void ExportarPadresAPDF(iTextDocument document, ConfiguracionExportacion config)
        {
            var padres = _dataService.ObtenerTodosLosPadres();

            // Crear tabla
            var numColumnas = 2 + (config.IncluirTelefonos ? 1 : 0) + (config.IncluirComentarios ? 1 : 0);
            var table = new PdfPTable(numColumnas);
            table.WidthPercentage = 100;

            // Encabezados
            table.AddCell(CrearCeldaPDF("PADRE", true));
            table.AddCell(CrearCeldaPDF("ALUMNO", true));
            if (config.IncluirTelefonos)
                table.AddCell(CrearCeldaPDF("TELÉFONO", true));
            if (config.IncluirComentarios)
                table.AddCell(CrearCeldaPDF("COMENTARIO", true));

            // Datos
            foreach (var padre in padres)
            {
                table.AddCell(CrearCeldaPDF(padre.Nombre, false));
                table.AddCell(CrearCeldaPDF(padre.Alumno ?? "No especificado", false));
                if (config.IncluirTelefonos)
                    table.AddCell(CrearCeldaPDF(padre.Contacto ?? "No especificado", false));
                if (config.IncluirComentarios)
                    table.AddCell(CrearCeldaPDF(padre.Comentario ?? "Sin comentarios", false));
            }

            document.Add(table);
        }

        private void ExportarTareasAPDF(iTextDocument document, ConfiguracionExportacion config)
        {
            var tareas = _dataService.ObtenerTodasLasTareas();

            var numColumnas = 2 + (config.IncluirFechas ? 1 : 0);
            var table = new PdfPTable(numColumnas);
            table.WidthPercentage = 100;

            // Encabezados
            table.AddCell(CrearCeldaPDF("TAREA", true));
            table.AddCell(CrearCeldaPDF("VECES ASIGNADA", true));
            if (config.IncluirFechas)
                table.AddCell(CrearCeldaPDF("FECHA CREACIÓN", true));

            // Datos
            foreach (var tarea in tareas)
            {
                table.AddCell(CrearCeldaPDF(tarea.Descripcion, false));
                table.AddCell(CrearCeldaPDF(tarea.VecesAsignada.ToString(), false));
                if (config.IncluirFechas)
                    table.AddCell(CrearCeldaPDF(tarea.FechaCreacion.ToString("dd/MM/yyyy"), false));
            }

            document.Add(table);
        }

        private void ExportarListaCompletaAPDF(iTextDocument document, ConfiguracionExportacion config)
        {
            var datos = _dataService.ObtenerPadresConTareas();

            var numColumnas = 2 + (config.IncluirTelefonos ? 1 : 0) + 1 +
                            (config.IncluirEstado ? 1 : 0) + (config.IncluirFechas ? 1 : 0);

            var table = new PdfPTable(numColumnas);
            table.WidthPercentage = 100;

            // Encabezados
            table.AddCell(CrearCeldaPDF("PADRE", true));
            table.AddCell(CrearCeldaPDF("ALUMNO", true));
            if (config.IncluirTelefonos)
                table.AddCell(CrearCeldaPDF("TELÉFONO", true));
            table.AddCell(CrearCeldaPDF("TAREA", true));
            if (config.IncluirEstado)
                table.AddCell(CrearCeldaPDF("ESTADO", true));
            if (config.IncluirFechas)
                table.AddCell(CrearCeldaPDF("FECHA", true));

            // Datos
            foreach (var dato in datos)
            {
                table.AddCell(CrearCeldaPDF(dato.NombrePadre, false));
                table.AddCell(CrearCeldaPDF(dato.NombreAlumno, false));
                if (config.IncluirTelefonos)
                    table.AddCell(CrearCeldaPDF(dato.Contacto ?? "No especificado", false));
                table.AddCell(CrearCeldaPDF(dato.TareaActual, false));
                if (config.IncluirEstado)
                {
                    var estadoCell = CrearCeldaPDF(dato.StatusTarea, false);
                    // Color para estados
                    switch (dato.StatusTarea)
                    {
                        case "Cumplida":
                            estadoCell.BackgroundColor = BaseColor.Green;
                            break;
                        case "En Proceso":
                            estadoCell.BackgroundColor = BaseColor.Yellow;
                            break;
                        case "Incumplida":
                            estadoCell.BackgroundColor = BaseColor.Red;
                            break;
                    }
                    table.AddCell(estadoCell);
                }
                if (config.IncluirFechas)
                    table.AddCell(CrearCeldaPDF(dato.FechaAsignacion.ToString("dd/MM/yyyy"), false));
            }

            document.Add(table);
        }

        private PdfPCell CrearCeldaPDF(string texto, bool isHeader)
        {
            var font = isHeader ?
                FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10, BaseColor.White) :
                FontFactory.GetFont(FontFactory.HELVETICA, 9, BaseColor.Black);

            var cell = new PdfPCell(new Phrase(texto, font))
            {
                BackgroundColor = isHeader ? BaseColor.DarkGray : BaseColor.White,
                Padding = 5,
                BorderWidth = 0.5f
            };

            return cell;
        }

        private void MostrarVistaPrevia(ConfiguracionExportacion config)
        {
            int totalRegistros = 0;
            string tipoDatos = "";

            switch (config.ListaSeleccionada)
            {
                case "PADRES":
                    var padres = _dataService.ObtenerTodosLosPadres();
                    totalRegistros = padres.Count;
                    tipoDatos = "padres registrados";
                    break;
                case "TAREAS":
                    var tareas = _dataService.ObtenerTodasLasTareas();
                    totalRegistros = tareas.Count;
                    tipoDatos = "tareas creadas";
                    break;
                case "COMPLETA":
                    var completa = _dataService.ObtenerPadresConTareas();
                    totalRegistros = completa.Count;
                    tipoDatos = "registros de padres con tareas";
                    break;
            }

            string vistaPrevia = $"VISTA PREVIA DE EXPORTACIÓN\n\n" +
                               $"Lista seleccionada: {config.ListaSeleccionada}\n" +
                               $"Formato: {config.Formato}\n" +
                               $"Total de registros: {totalRegistros} {tipoDatos}\n\n" +
                               $"Configuración aplicada:\n" +
                               $"   • Incluir fechas: {(config.IncluirFechas ? "Sí" : "No")}\n" +
                               $"   • Incluir estado: {(config.IncluirEstado ? "Sí" : "No")}\n" +
                               $"   • Incluir teléfonos: {(config.IncluirTelefonos ? "Sí" : "No")}\n" +
                               $"   • Incluir comentarios: {(config.IncluirComentarios ? "Sí" : "No")}\n" +
                               $"   • Formato tabla: {(config.FormatoTabla ? "Sí" : "No")}";

            MessageBox.Show(vistaPrevia, "Vista Previa de Exportación",
                          MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private string GenerarNombreArchivo(ConfiguracionExportacion config)
        {
            string fecha = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            return $"Exportacion_{config.ListaSeleccionada}_{fecha}";
        }

        private void MostrarMensajeExito(string filePath, string formato)
        {
            var resultado = MessageBox.Show(
                $"Exportación a {formato} completada exitosamente.\n\n" +
                $"Archivo: {Path.GetFileName(filePath)}\n\n" +
                $"¿Desea abrir el archivo exportado?",
                "Exportación Completada",
                MessageBoxButton.YesNo,
                MessageBoxImage.Information);

            if (resultado == MessageBoxResult.Yes)
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = filePath,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al abrir el archivo: {ex.Message}", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }


        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

        public class ConfiguracionExportacion
        {
            public string ListaSeleccionada { get; set; }
            public string Formato { get; set; }
            public bool IncluirFechas { get; set; }
            public bool IncluirEstado { get; set; }
            public bool IncluirTelefonos { get; set; }
            public bool IncluirComentarios { get; set; }
            public bool FormatoTabla { get; set; }
        }
    }
}