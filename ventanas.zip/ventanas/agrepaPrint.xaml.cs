﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class agrepaPrint : Window
    {
        private DataService _dataService;

        public agrepaPrint()
        {
            InitializeComponent();
            _dataService = new DataService();
        }

        private void btnGuardar_Click(object sender, RoutedEventArgs e)
        {
            // Validar que el texto no sea del placeholder
            if (txtNombre.Text == "Ingrese el nombre del padre" || string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El nombre es obligatorio", "Validación",
                          MessageBoxButton.OK, MessageBoxImage.Warning);
                txtNombre.Focus();
                return;
            }

            // Verificar si el nombre ingresado ya existe
            string nombre = txtNombre.Text.Trim();
            if (nombre != "Ingrese el nombre del padre" && _dataService.ExistePadre(nombre))
            {
                MessageBox.Show("Ya existe un padre registrado con este nombre", "Validación",
                           MessageBoxButton.OK, MessageBoxImage.Warning);
                txtNombre.Focus();
                return;
            }

            Padre nuevoPadre = new Padre
            {
                Nombre = nombre,
                Contacto = (txtTelefono.Text == "Ingrese el numero de télefono" || string.IsNullOrWhiteSpace(txtTelefono.Text)) ? null : txtTelefono.Text.Trim(),
                Alumno = (txtnomAlumno.Text == "Ingrese el nombre del alumno" || string.IsNullOrWhiteSpace(txtnomAlumno.Text)) ? null : txtnomAlumno.Text.Trim(),
                Comentario = (txtComentarios.Text == "Ingrese algo a destacar" || string.IsNullOrWhiteSpace(txtComentarios.Text)) ? null : txtComentarios.Text.Trim(),
            };

            bool resultado = _dataService.GuardarPadre(nuevoPadre);

            if (resultado)
            {
                MessageBox.Show("Padre registrado exitosamente", "Éxito",
                           MessageBoxButton.OK, MessageBoxImage.Information);
                LimpiarFormulario();
            }
            else
            {
                MessageBox.Show("Error al registrar el padre", "Error",
                            MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cancelar? Los datos se perderán.",
                                           "Confirmar Cancelación",
                                            MessageBoxButton.YesNo,
                                            MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
                menuWindow.Show();
                this.Close();
            }
        }

        // Restaurar los placeholders al termino de la acción
        private void LimpiarFormulario()
        {
            txtNombre.Text = "Ingrese el nombre del padre";
            txtNombre.Foreground = Brushes.Gray;

            txtTelefono.Text = "Ingrese el numero de télefono";
            txtTelefono.Foreground = Brushes.Gray;

            txtnomAlumno.Text = "Ingrese el nombre del alumno";
            txtnomAlumno.Foreground = Brushes.Gray;

            txtComentarios.Text = "Ingrese algo a destacar";
            txtComentarios.Foreground = Brushes.Gray;

            txtNombre.Focus();
        }

        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarPadres = new modificarPadres();
            modificarPadres.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                // Restaurar el placeholder según el TextBox
                if (textBox.Name == "txtNombre")
                    textBox.Text = "Ingrese el nombre del padre";
                else if (textBox.Name == "txtTelefono")
                    textBox.Text = "Ingrese el numero de télefono";
                else if (textBox.Name == "txtnomAlumno")
                    textBox.Text = "Ingrese el nombre del alumno";
                else if (textBox.Name == "txtComentarios")
                    textBox.Text = "Ingrese algo a destacar";

                textBox.Foreground = Brushes.Gray;
            }
        }

    }
}