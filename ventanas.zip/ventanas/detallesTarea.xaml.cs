﻿using eduTask.baseDatos;
using eduTask.Utils;
using eduTask.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Diagnostics;

namespace eduTask.ventanas
{
    public partial class detallesTarea : Window
    {
        private DataService _dataService;
        private int _idPadreSeleccionado;
        private List<TareaActivaPadre> _tareasActivas;
        private TareaActivaPadre _tareaSeleccionada;
        private int? _idAsignacionInicial;


        public detallesTarea()
        {
            InitializeComponent();
            _dataService = new DataService();
            InicializarVentana();
        }

        public detallesTarea(int idAsignacion)
        {
            InitializeComponent();
            _idAsignacionInicial = idAsignacion;
            InicializarVentana();
            CargarDatosDesdeAsignacion(idAsignacion);
        }

        private void InicializarVentana() 
        {
            InitializeComponent();
            _dataService = new DataService();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Configurar TextBox de búsqueda
            txtBuscarPadre.GotFocus += (s, e) =>
            {
                if (txtBuscarPadre.Text == "Ingrese el nombre del padre...")
                    txtBuscarPadre.Text = "";
            };

            txtBuscarPadre.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtBuscarPadre.Text))
                    txtBuscarPadre.Text = "Ingrese el nombre del padre...";
            };

            // Configurar TextBox de penalización
            txtPenalizacion.GotFocus += (s, e) =>
            {
                if (txtPenalizacion.Text == "Describa la penalización...")
                    txtPenalizacion.Text = "";
            };

            txtPenalizacion.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtPenalizacion.Text))
                    txtPenalizacion.Text = "Describa la penalización...";
            };
        }

        private void CargarDatosDesdeAsignacion(int idAsignacion)
        {
            try
            {
                // Obtener información de la asignación y el padre
                var datosAsignacion = _dataService.ObtenerDatosAsignacionConPadre(idAsignacion);

                if (datosAsignacion == null)
                {
                    MessageBox.Show("No se encontró información de la asignación especificada.",
                                  "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Configurar búsqueda con el nombre del padre
                txtBuscarPadre.Text = datosAsignacion.NombrePadre;
                _idPadreSeleccionado = datosAsignacion.IdPadre;

                // Mostrar información del padre
                txtNombrePadre.Text = datosAsignacion.NombrePadre;
                txtNombreAlumno.Text = datosAsignacion.NombreAlumno ?? "No especificado";
                txtContactoPadre.Text = datosAsignacion.Contacto ?? "No especificado";

                // Cargar tareas activas del padre
                CargarTareasActivas();

                // Mostrar paneles
                borderInfoPadre.Visibility = Visibility.Visible;
                borderTareas.Visibility = Visibility.Visible;
                borderBotones.Visibility = Visibility.Visible;

                // Seleccionar automáticamente la tarea específica en el DataGrid
                if (_tareasActivas != null && _tareasActivas.Count > 0)
                {
                    var tareaEspecifica = _tareasActivas.FirstOrDefault(t => t.IdAsignacion == idAsignacion);
                    if (tareaEspecifica != null)
                    {
                        dgTareasActivas.SelectedItem = tareaEspecifica;
                        dgTareasActivas.ScrollIntoView(tareaEspecifica);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos de la asignación: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void btnBuscarPadre_Click(object sender, RoutedEventArgs e)
        {
            string nombrePadre = txtBuscarPadre.Text.Trim();
            if (string.IsNullOrWhiteSpace(nombrePadre) || nombrePadre == "Ingrese el nombre del padre...")
            {
                MessageBox.Show("Por favor ingrese el nombre del padre a buscar.",
                              "Campo Vacío", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Buscar padres por nombre (coincidencia parcial)
                var padres = _dataService.BuscarPadresPorNombre(nombrePadre);

                if (padres == null || padres.Count == 0)
                {
                    MessageBox.Show($"No se encontró ningún padre con el nombre: {nombrePadre}",
                                  "Padre No Encontrado", MessageBoxButton.OK, MessageBoxImage.Information);
                    OcultarPaneles();
                    return;
                }

                Padre padreSeleccionado;

                // Si hay múltiples resultados, mostrar para seleccionar
                if (padres.Count > 1)
                {
                    string opciones = "Se encontraron varios padres:\n\n";
                    for (int i = 0; i < padres.Count; i++)
                    {
                        opciones += $"{i + 1}. {padres[i].Nombre} - Alumno: {padres[i].Alumno ?? "N/A"}\n";
                    }
                    opciones += "\nPor favor, sea más específico en su búsqueda o seleccione al primer resultado.";

                    var result = MessageBox.Show(opciones, "Múltiples Resultados",
                                               MessageBoxButton.OKCancel, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Cancel)
                    {
                        return;
                    }

                    // Seleccionar el primero por defecto
                    padreSeleccionado = padres[0];
                }
                else
                {
                    // Si solo hay un resultado, seleccionarlo directamente
                    padreSeleccionado = padres[0];
                }

                _idPadreSeleccionado = padreSeleccionado.IdPadre;

                // Mostrar información del padre
                txtNombrePadre.Text = padreSeleccionado.Nombre;
                txtNombreAlumno.Text = padreSeleccionado.Alumno ?? "No especificado";
                txtContactoPadre.Text = padreSeleccionado.Contacto ?? "No especificado";

                // Cargar tareas activas del padre
                CargarTareasActivas();

                // Mostrar paneles
                borderInfoPadre.Visibility = Visibility.Visible;
                borderTareas.Visibility = Visibility.Visible;
                borderBotones.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar padre: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CargarTareasActivas()
        {
            try
            {
                _tareasActivas = _dataService.ObtenerTareasActivasPorPadre(_idPadreSeleccionado);

                if (_tareasActivas == null || _tareasActivas.Count == 0)
                {
                    MessageBox.Show("Este padre no tiene tareas activas asignadas.",
                                  "Sin Tareas", MessageBoxButton.OK, MessageBoxImage.Information);
                    dgTareasActivas.ItemsSource = null;
                    return;
                }

                dgTareasActivas.ItemsSource = _tareasActivas;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgTareasActivas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgTareasActivas.SelectedItem != null)
            {
                _tareaSeleccionada = (TareaActivaPadre)dgTareasActivas.SelectedItem;
                btnMarcarCumplida.IsEnabled = true;
                btnMarcarIncumplida.IsEnabled = true;
                borderPenalizacion.Visibility = Visibility.Collapsed;

                // Mostrar botón de detalles cooperación solo si es tipo cooperación
                if (_tareaSeleccionada.TipoTarea != null &&
                    _tareaSeleccionada.TipoTarea.Equals("Cooperacion", StringComparison.OrdinalIgnoreCase))
                {
                    btnIrDetallesCooperacion.Visibility = Visibility.Visible;
                }
                else
                {
                    btnIrDetallesCooperacion.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                _tareaSeleccionada = null;
                btnMarcarCumplida.IsEnabled = false;
                btnMarcarIncumplida.IsEnabled = false;
                borderPenalizacion.Visibility = Visibility.Collapsed;
                btnIrDetallesCooperacion.Visibility = Visibility.Collapsed;
            }
        }

        private void btnMarcarCumplida_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea de la tabla.",
                              "Sin Selección", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var resultado = MessageBox.Show(
                $"¿Está seguro de marcar como CUMPLIDA la tarea?\n\n" +
                $"Tarea: {_tareaSeleccionada.TituloTarea}\n" +
                $"Padre: {txtNombrePadre.Text}\n" +
                $"Alumno: {txtNombreAlumno.Text}",
                "Confirmar Cumplida",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                try
                {
                    bool actualizado = _dataService.ActualizarEstadoTarea(
                        _tareaSeleccionada.IdAsignacion,
                        "cumplida",
                        null);

                    if (actualizado)
                    {
                        MessageBox.Show("Tarea marcada como CUMPLIDA exitosamente.",
                                      "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);

                        // Recargar tareas
                        CargarTareasActivas();
                        dgTareasActivas.SelectedItem = null;
                        borderPenalizacion.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el estado de la tarea.",
                                      "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar tarea: {ex.Message}", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnMarcarIncumplida_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea de la tabla.",
                              "Sin Selección", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Mostrar panel de penalización
            borderPenalizacion.Visibility = Visibility.Visible;
            txtPenalizacion.Text = "Describa la penalización...";
            txtPenalizacion.Focus();
        }

        private void btnConfirmarIncumplida_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea de la tabla.",
                              "Sin Selección", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string penalizacion = txtPenalizacion.Text.Trim();

            if (string.IsNullOrWhiteSpace(penalizacion) || penalizacion == "Describa la penalización...")
            {
                MessageBox.Show("Por favor describa la penalización antes de continuar.",
                              "Campo Vacío", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var resultado = MessageBox.Show(
                $"¿Está seguro de marcar como INCUMPLIDA la tarea?\n\n" +
                $"Tarea: {_tareaSeleccionada.TituloTarea}\n" +
                $"Padre: {txtNombrePadre.Text}\n" +
                $"Alumno: {txtNombreAlumno.Text}\n\n" +
                $"Penalización: {penalizacion}",
                "Confirmar Incumplida",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (resultado == MessageBoxResult.Yes)
            {
                try
                {
                    bool actualizado = _dataService.ActualizarEstadoTarea(
                        _tareaSeleccionada.IdAsignacion,
                        "incumplida",
                        penalizacion);

                    if (actualizado)
                    {
                        MessageBox.Show("Tarea marcada como INCUMPLIDA exitosamente.",
                                      "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);

                        // Recargar tareas
                        CargarTareasActivas();
                        dgTareasActivas.SelectedItem = null;
                        borderPenalizacion.Visibility = Visibility.Collapsed;
                        txtPenalizacion.Text = "Describa la penalización...";
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el estado de la tarea.",
                                      "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar tarea: {ex.Message}", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        // En tu ventana detallesTarea, el método que abre detallesCooperacion
        private void btnIrDetallesCooperacion_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // ✅ Verificar que haya una tarea seleccionada
                if (dgTareasActivas.SelectedItem == null)
                {
                    MessageBox.Show(
                        "Por favor, selecciona una tarea de la tabla para ver sus detalles de cooperación.",
                        "Ninguna Tarea Seleccionada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                // ✅ Obtener el objeto seleccionado (ajusta el tipo según tu modelo)
                dynamic tareaSeleccionada = dgTareasActivas.SelectedItem;

                Debug.WriteLine($"DEBUG - Tipo de objeto: {tareaSeleccionada.GetType().Name}");

                // ✅ Verificar que sea una cooperación
                if (tareaSeleccionada.TipoTarea != "Cooperación" &&
                    tareaSeleccionada.TipoTarea != "cooperacion")
                {
                    MessageBox.Show(
                        "La tarea seleccionada no es una cooperación.\n\n" +
                        "Solo las tareas de tipo 'Cooperación' tienen detalles de pago.",
                        "Tipo de Tarea Inválido",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                // ✅ Obtener el IdAsignacion
                int idAsignacion = tareaSeleccionada.IdAsignacion;

                Debug.WriteLine($"DEBUG - Abriendo detalles cooperación con ID: {idAsignacion}");

                detallesCooperacion ventanaCooperacion = new detallesCooperacion(idAsignacion);
                ventanaCooperacion.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR - {ex.Message}");
                Debug.WriteLine($"ERROR - StackTrace: {ex.StackTrace}");

                MessageBox.Show(
                    $"Error al abrir detalles de cooperación:\n\n{ex.Message}",
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void OcultarPaneles()
        {
            borderInfoPadre.Visibility = Visibility.Collapsed;
            borderTareas.Visibility = Visibility.Collapsed;
            borderBotones.Visibility = Visibility.Collapsed;
            borderPenalizacion.Visibility = Visibility.Collapsed;
            btnIrDetallesCooperacion.Visibility = Visibility.Collapsed;
            dgTareasActivas.ItemsSource = null;
        }

        // Métodos de navegación del menú
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}