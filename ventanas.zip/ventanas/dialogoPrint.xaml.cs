﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace eduTask
{
    public partial class dialogoPrint : Window
    {
        public string TipoPenalizacionSeleccionada { get; private set; }
        public string DescripcionPenalizacion { get; private set; }
        public bool PenalizacionCumplida { get; private set; }

        public string NombrePadre { get; set; }
        public int CantidadTareas { get; set; }

        public dialogoPrint()
        {
            try
            {
                InitializeComponent();
                PenalizacionCumplida = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al inicializar la ventana: {ex.Message}",
                              "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                // Verificar que los controles existen antes de usarlos
                if (runNombrePadre != null && runCantidadTareas != null)
                {
                    // Mostrar información del padre
                    if (!string.IsNullOrEmpty(NombrePadre))
                    {
                        runNombrePadre.Text = NombrePadre;
                        runCantidadTareas.Text = CantidadTareas.ToString();
                    }
                }

                // Inicializar ComboBox si existe
                if (cbTipoPenalizacion != null && cbTipoPenalizacion.Items.Count > 0)
                {
                    cbTipoPenalizacion.SelectedIndex = 0;
                }

                // Actualizar estado inicial
                ActualizarEstadoBoton();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar el formulario: {ex.Message}",
                              "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ActualizarEstadoBoton()
        {
            try
            {
                // Verificar que btnAceptar existe
                if (btnAceptar == null)
                {
                    // Si btnAceptar es null, intentar encontrarlo
                    btnAceptar = FindName("btnAceptar") as Button;

                    if (btnAceptar == null)
                    {
                        // Si aún es null, mostrar error y salir
                        return;
                    }
                }

                bool camposValidos = ValidarCampos();
                btnAceptar.IsEnabled = camposValidos;
                ActualizarMensajeEstado();
            }
            catch
            {
                // Silenciar errores
            }
        }

        private bool ValidarCampos()
        {
            try
            {
                // Verificar que el ComboBox existe y tiene selección
                if (cbTipoPenalizacion == null || cbTipoPenalizacion.SelectedItem == null)
                    return false;

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void ActualizarMensajeEstado()
        {
            try
            {
                // Verificar que los controles existen
                if (txtMensaje == null || borderMensaje == null || chkPenalizacionCumplida == null)
                    return;

                bool camposValidos = ValidarCampos();
                bool penalizacionCumplida = chkPenalizacionCumplida.IsChecked == true;

                if (!camposValidos)
                {
                    txtMensaje.Text = "Seleccione un tipo de penalización para continuar";
                    borderMensaje.Background = System.Windows.Media.Brushes.LightPink;
                    borderMensaje.BorderBrush = System.Windows.Media.Brushes.Red;
                }
                else if (!penalizacionCumplida)
                {
                    txtMensaje.Text = "La penalización se registrará como PENDIENTE\n" +
                                     "Deberá cumplirla antes de poder generar el vale de liberación";
                    borderMensaje.Background = System.Windows.Media.Brushes.LightYellow;
                    borderMensaje.BorderBrush = System.Windows.Media.Brushes.Orange;
                }
                else
                {
                    txtMensaje.Text = "Todo listo! La penalización se registrará como CUMPLIDA\n" +
                                     "Podrá generar el vale de liberación inmediatamente";
                    borderMensaje.Background = System.Windows.Media.Brushes.LightGreen;
                    borderMensaje.BorderBrush = System.Windows.Media.Brushes.Green;
                }
            }
            catch
            {
                // Ignorar errores
            }
        }

        private void CbTipoPenalizacion_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ActualizarEstadoBoton();
        }

        private void TxtDescripcion_TextChanged(object sender, TextChangedEventArgs e)
        {
            // No es necesario validar, pero actualizamos el estado
            ActualizarEstadoBoton();
        }

        private void ChkPenalizacionCumplida_Checked(object sender, RoutedEventArgs e)
        {
            PenalizacionCumplida = true;
            ActualizarEstadoBoton();
        }

        private void ChkPenalizacionCumplida_Unchecked(object sender, RoutedEventArgs e)
        {
            PenalizacionCumplida = false;
            ActualizarEstadoBoton();
        }

        private void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Verificar que los controles existen
                if (cbTipoPenalizacion == null)
                {
                    MessageBox.Show("Error interno: Controles no inicializados.",
                                  "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    DialogResult = false;
                    return;
                }

                // Validación simplificada
                if (cbTipoPenalizacion.SelectedItem == null)
                {
                    MessageBox.Show("Seleccione un tipo de penalización para continuar.",
                                  "Datos Incompletos",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Obtener datos del formulario
                if (cbTipoPenalizacion.SelectedItem is ComboBoxItem selectedItem)
                {
                    TipoPenalizacionSeleccionada = selectedItem.Content?.ToString() ?? "No especificado";
                }
                else
                {
                    TipoPenalizacionSeleccionada = "No especificado";
                }

                // La descripción es opcional
                DescripcionPenalizacion = txtDescripcion?.Text?.Trim() ?? "";

                // Estado del checkbox
                PenalizacionCumplida = chkPenalizacionCumplida?.IsChecked ?? false;

                // Cerrar con éxito
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al procesar el formulario: {ex.Message}",
                              "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                DialogResult = false;
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}