﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class busquedaPrint : Window
    {
        private DataService _dataService;
        private List<PadreTarea> _todosLosResultados;
        private string _filtroActual;

        public busquedaPrint()
        {
            InitializeComponent();

            // ESPERA a que XAML esté listo
            this.Dispatcher.Invoke(async () =>
            {
                await Task.Delay(50); // tiempo de espera

                _dataService = new DataService();
                _filtroActual = "TODOS";
                _todosLosResultados = new List<PadreTarea>();
                ConfigurarPlaceholders();

                if (rbTodos != null)
                    rbTodos.IsChecked = true;

                CargarTodosLosPadres();
            });
        }
        private void ConfigurarPlaceholders()
        {
            txtBusquedaRapida.Text = "Buscar por nombre de padre o alumno...";
            txtBusquedaRapida.Foreground = Brushes.Gray;
        }

        private void CargarTodosLosPadres()
        {
            try
            {
                _todosLosResultados = _dataService.ObtenerPadresConTareas();
                if (_todosLosResultados == null)
                {
                    _todosLosResultados = new List<PadreTarea>();
                }
                ActualizarResultados();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                _todosLosResultados = new List<PadreTarea>();
                ActualizarResultados();
            }
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            RealizarBusqueda();
        }

        private void RealizarBusqueda()
        {
            string textoBusqueda = txtBusquedaRapida.Text.Trim();

            if (textoBusqueda == "Buscar por nombre de padre o alumno..." || textoBusqueda == "")
            {
                textoBusqueda = "";
            }

            try
            {
                List<PadreTarea> resultados;

                if (string.IsNullOrEmpty(textoBusqueda) && _filtroActual == "TODOS")
                {
                    resultados = _todosLosResultados ?? new List<PadreTarea>();
                }
                else
                {
                    resultados = _dataService.BuscarPadresConTareas(textoBusqueda, _filtroActual);
                }

                MostrarResultados(resultados);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en la búsqueda: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                MostrarResultados(new List<PadreTarea>());
            }
        }

        private void FiltroEstado_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton radioButton && radioButton.IsChecked == true)
            {
                _filtroActual = radioButton.Content.ToString().ToUpper();

                // Asegurar que "TODOS" se envíe correctamente
                if (_filtroActual == "TODOS")
                {
                    _filtroActual = "TODOS"; 
                }

                RealizarBusqueda();
            }
        }

        private void MostrarResultados(List<PadreTarea> resultados)
        {
            try
            {

                if (Resultados == null)
                {
                    MessageBox.Show("Cargando datos");
                    return;
                }

                // Asegurar que no sea null
                resultados = resultados ?? new List<PadreTarea>();

                Resultados.ItemsSource = resultados;

                // Validar también txtContadorResultados
                if (txtContadorResultados != null)
                {
                    txtContadorResultados.Text = $" - {resultados.Count} registros encontrados";
                }

                // Validar txtMensaje
                if (txtMensaje != null)
                {
                    if (resultados.Count > 0)
                    {
                        txtMensaje.Visibility = Visibility.Collapsed;
                        Resultados.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        txtMensaje.Visibility = Visibility.Visible;
                        Resultados.Visibility = Visibility.Collapsed;
                        txtMensaje.Text = "No se encontraron resultados con los criterios de búsqueda actuales";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al mostrar resultados:{ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error
                   );
            }
        }

        private void ActualizarResultados()
        {
            if (_todosLosResultados != null)
            {
                MostrarResultados(_todosLosResultados);
            }
        }

        private void btnAgregar_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agragarWindow = new agrepaPrint();
            agragarWindow.Show();
            this.Close();
        }

        private void btnAgregarTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        // Métodos de placeholder
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Buscar por nombre de padre o alumno...";
                textBox.Foreground = Brushes.Gray;
            }
        }

        private void VerificarYMostrarControles()
        {
            var controlesFaltantes = new List<string>();

            var controles = new Dictionary<string, object>
                {
                    { "lstResultados", Resultados },
                    { "txtBusquedaRapida", txtBusquedaRapida },
                    { "txtContadorResultados", txtContadorResultados },
                    { "txtMensaje", txtMensaje },
                    { "rbTodos", rbTodos },
                    { "rbEnProceso", rbEnProceso },
                    { "rbCumplidas", rbCumplidas },
                    { "rbIncumplidas", rbIncumplidas },
                    { "btnBuscar", btnBuscar },
                    { "btnLimpiar", btnAgregar },
                    { "btnExportar", btnAgregarTarea }
                };

            foreach (var control in controles)
            {
                if (control.Value == null)
                {
                    controlesFaltantes.Add(control.Key);
                }
            }

            if (controlesFaltantes.Count > 0)
            {
                string mensaje = "Controles no encontrados:\n" + string.Join("\n", controlesFaltantes);
                MessageBox.Show(mensaje, "Advertencia", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            // Ya estamos en esta ventana
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}