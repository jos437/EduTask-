﻿using eduTask.baseDatos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eduTask.ventanas;
using eduTask.Utils;


namespace eduTask.ventanas
{
    public partial class loginPrint : Window
    {
        private DataService _dataService;
        private const string UsuarioPlaceholder = "Ingrese su usuario";
        private bool isPasswordVisible = false;
        public loginPrint()
        {
            InitializeComponent();
            _dataService = new DataService();
            sesionGlobal.CerrarSesion();

            SetupPlaceholders();

            if (txtusuario != null)
            {
                txtusuario.Focus();
                txtusuario.KeyDown += Txtusuario_KeyDown;
            }

            if (txtcontraseña != null)
            {
                txtcontraseña.KeyDown += Txtcontraseña_KeyDown;
            }

        }


        private void btnMostrarContraseña_Click(object sender, RoutedEventArgs e)
        {
            if (!isPasswordVisible)
            {
                // Mostrar contraseña
                txtContraseñaVisible.Text = txtcontraseña.Password;
                txtcontraseña.Visibility = Visibility.Collapsed;
                txtContraseñaVisible.Visibility = Visibility.Visible;

                btnMostrarContraseña.Content = "🔒";
                btnMostrarContraseña.ToolTip = "Ocultar contraseña";
                isPasswordVisible = true;
            }
            else
            {
                // Ocultar contraseña
                txtcontraseña.Password = txtContraseñaVisible.Text;
                txtContraseñaVisible.Visibility = Visibility.Collapsed;
                txtcontraseña.Visibility = Visibility.Visible;

                btnMostrarContraseña.Content = "👁";
                btnMostrarContraseña.ToolTip = "Mostrar contraseña";
                isPasswordVisible = false;
            }
        }

        private string getPassword()
        {
            return isPasswordVisible ? txtContraseñaVisible.Text : txtcontraseña.Password;
        } 
        private void SetupPlaceholders()
        {
            txtusuario.Text = UsuarioPlaceholder;
            txtusuario.Foreground = Brushes.Gray;
        }
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null)
            {
                if (textBox.Text == UsuarioPlaceholder)
                {
                    textBox.Text = "";
                    textBox.Foreground = Brushes.Black;
                }
            }
        }
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null)
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = UsuarioPlaceholder;
                    textBox.Foreground = Brushes.Gray;
                }
            }
        }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.IsFocused)
            {
                if (textBox.Text == UsuarioPlaceholder && textBox.Foreground == Brushes.Gray)
                {
                    textBox.Text = "";
                    textBox.Foreground = Brushes.Black;
                }
            }
        }

        private void bttningresar_Click(object sender, RoutedEventArgs e)
        {
            IniciarSesion();
        }

        private void bttnOlvideCon_Click(object sender, RoutedEventArgs e)
        {
            ShowPasswordRecovery();
        }

        private void Txtcontraseña_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                IniciarSesion();
            }
        }

        private void Txtusuario_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (txtcontraseña !=null)
                    txtcontraseña.Focus();
            }
        }

        private async Task AttemptLogin()
        {
            if (txtusuario == null|| txtcontraseña == null)
            {
                ShowError("error al iniciar los controladores.");
                return;
            }
                       
            string usuario = txtusuario.Text.Trim();
            string password = txtcontraseña.Password;

            
            if (usuario == UsuarioPlaceholder)
            {
                usuario = "";
            }

            if (string.IsNullOrEmpty(usuario))
            {
                ShowError("Por favor, ingrese su usuario.");
                txtusuario.Focus();
                return;
            }


            if (string.IsNullOrEmpty(password))
            {
                ShowError("Por favor, ingrese su contraseña.");
                txtcontraseña.Focus();
                return;
            }

            if (bttningresar != null)
                bttningresar.IsEnabled = false;

            try
            {
                var usuarioAutenticado = await Task.Run(() =>
                {
                    return _dataService.AutenticarUsuario(usuario, password);
                });

                if (usuarioAutenticado != null)
                {
                    OpenMainWindow(usuarioAutenticado);
                }
                else
                {
                    ShowError("Credenciales incorrectas. Por favor, verifique su usuario y contraseña.");
                    txtcontraseña.DataContext = "";
                    txtcontraseña.Focus();
                }
            }
            catch (Exception ex)
            {
                ShowError($"Error durante el login: {ex.Message}");
            }
            finally
            {
                if (bttningresar != null)
                    bttningresar.IsEnabled = true;
            }
        }

        private void OpenMainWindow(Modelos.Usuario usuario)
        {
            MenuPrint mainWindow = new MenuPrint(usuario);
            mainWindow.Show();
            this.Close();
        }

        private void ShowPasswordRecovery()
        {
            MessageBox.Show("Por favor, contacte al administrador del sistema para recuperar su contraseña.",
                          "",
                          MessageBoxButton.OK,
                          MessageBoxImage.Information);
        }

        private void ShowError(string mensaje)
        {
            MessageBox.Show(mensaje, "Error de Autenticación",
                          MessageBoxButton.OK,
                          MessageBoxImage.Error);
        }

        private void IniciarSesion()
        {
            // Validar campos vacíos
            if (string.IsNullOrWhiteSpace(txtusuario.Text))
            {
                MessageBox.Show("Por favor ingrese su usuario", "Campo Requerido",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtusuario.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtcontraseña.Password))
            {
                MessageBox.Show("Por favor ingrese su contraseña", "Campo Requerido",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtcontraseña.Focus();
                return;
            }

            try
            {

                // Autenticar usuario
                var usuario = _dataService.AutenticarUsuario(
                    txtusuario.Text.Trim(),
                    txtcontraseña.Password);

                if (usuario != null)
                {
                    //INICIAR SESIÓN GLOBAL
                    sesionGlobal.IniciarSesion(usuario);
                    OpenMainWindow(usuario);
                }
                else
                {
                    MessageBox.Show("Usuario o contraseña incorrectos", "Error de Autenticación",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                    txtcontraseña.Clear();
                    txtusuario.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al iniciar sesión: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                // Restaurar botón
                bttningresar.IsEnabled = true;
                bttningresar.Content = "Iniciar Sesión";
            }
        }
    }
}