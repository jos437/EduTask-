﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class modiTareaPrint : Window
    {
        private DataService _dataService;
        private List<TareaInfo> _todasLasTareas;
        private TareaInfo _tareaSeleccionada;
        private int _idTareaActual;

        public modiTareaPrint()
        {
            InitializeComponent();
            _dataService = new DataService();
            ConfigurarPlaceholders();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Cargar tareas al iniciar
            CargarTareas();
        }

        private void ConfigurarPlaceholders()
        {
            txtBuscarTarea.Text = "Ingrese el nombre de la tarea a buscar";
            txtBuscarTarea.Foreground = Brushes.Gray;
        }
        private void CargarTareas()
        {
            try
            {
                _todasLasTareas = _dataService.ObtenerTodasLasTareasDetalladas();
                dgTareas.ItemsSource = _todasLasTareas;

                if (_todasLasTareas.Count == 0)
                {
                    MessageBox.Show("No hay tareas registradas en el sistema.", "Sin Tareas",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            BuscarTareas();
        }

        private void txtBuscarTarea_TextChanged(object sender, TextChangedEventArgs e)
        {
            BuscarTareas();
        }

        private void BuscarTareas()
        {
            if (_todasLasTareas == null || _todasLasTareas.Count == 0)
                return;

            string textoBusqueda = txtBuscarTarea.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(textoBusqueda))
            {
                dgTareas.ItemsSource = _todasLasTareas;
            }
            else
            {
                var tareasFiltradas = _todasLasTareas.Where(t =>
                    (t.Titulo != null && t.Titulo.ToLower().Contains(textoBusqueda)) ||
                    (t.Descripcion != null && t.Descripcion.ToLower().Contains(textoBusqueda)) ||
                    (t.Tipo != null && t.Tipo.ToLower().Contains(textoBusqueda))
                ).ToList();

                dgTareas.ItemsSource = tareasFiltradas;

                if (tareasFiltradas.Count == 0)
                {
                    MessageBox.Show("No se encontraron tareas que coincidan con la búsqueda.",
                                  "Sin Resultados", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void dgTareas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgTareas.SelectedItem != null)
            {
                _tareaSeleccionada = dgTareas.SelectedItem as TareaInfo;

                if (_tareaSeleccionada != null)
                {
                    CargarDatosTarea(_tareaSeleccionada);
                }
            }
            else
            {
                OcultarFormulario();
            }
        }

        private void CargarDatosTarea(TareaInfo tarea)
        {
            _idTareaActual = tarea.IdTarea;

            // Cargar datos en el formulario
            txtTitulo.Text = tarea.Titulo;
            txtDescripcion.Text = tarea.Descripcion;
            dpFechaLimite.SelectedDate = tarea.FechaLimite;

            // Seleccionar tipo de tarea
            foreach (ComboBoxItem item in cmbTipoTarea.Items)
            {
                if (item.Content.ToString() == tarea.Tipo)
                {
                    cmbTipoTarea.SelectedItem = item;
                    break;
                }
            }

            // Cargar monto si es cooperación
            if (tarea.Tipo == "cooperacion" && tarea.MontoCooperacion.HasValue)
            {
                txtMontoCooperacion.Text = tarea.MontoCooperacion.Value.ToString("F2");
            }
            else
            {
                txtMontoCooperacion.Clear();
            }

            // Mostrar formulario
            gridFormulario.Visibility = Visibility.Visible;
        }

        private void OcultarFormulario()
        {
            gridFormulario.Visibility = Visibility.Collapsed;
            LimpiarFormulario();
        }

        private void cmbTipoTarea_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (gridMontoCooperacion == null || cmbTipoTarea.SelectedItem == null)
                return;

            string tipoSeleccionado = (cmbTipoTarea.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (tipoSeleccionado == "cooperacion")
            {
                gridMontoCooperacion.Visibility = Visibility.Visible;
            }
            else
            {
                gridMontoCooperacion.Visibility = Visibility.Collapsed;
                if (txtMontoCooperacion != null)
                {
                    txtMontoCooperacion.Clear();
                }
            }
        }

        private void txtMontoCooperacion_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex(@"^[0-9]*\.?[0-9]*$");
            string textoCompleto = txtMontoCooperacion.Text.Insert(txtMontoCooperacion.CaretIndex, e.Text);

            if (textoCompleto.Split('.').Length > 2)
            {
                e.Handled = true;
                return;
            }

            e.Handled = !regex.IsMatch(textoCompleto);
        }

        private void btnGuardarCambios_Click(object sender, RoutedEventArgs e)
        {
            // Validaciones
            if (string.IsNullOrWhiteSpace(txtTitulo.Text))
            {
                MessageBox.Show("El título es obligatorio", "Campo Requerido",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtTitulo.Focus();
                return;
            }

            if (!dpFechaLimite.SelectedDate.HasValue)
            {
                MessageBox.Show("La fecha límite es obligatoria", "Campo Requerido",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                dpFechaLimite.Focus();
                return;
            }

            if (cmbTipoTarea.SelectedItem == null)
            {
                MessageBox.Show("Debe seleccionar un tipo de tarea", "Campo Requerido",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                cmbTipoTarea.Focus();
                return;
            }

            // Obtener datos
            string titulo = txtTitulo.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();
            DateTime fechaLimite = dpFechaLimite.SelectedDate.Value;
            string tipoTarea = (cmbTipoTarea.SelectedItem as ComboBoxItem)?.Content.ToString();

            decimal? montoCooperacion = null;
            if (tipoTarea == "cooperacion" && !string.IsNullOrWhiteSpace(txtMontoCooperacion.Text))
            {
                if (decimal.TryParse(txtMontoCooperacion.Text, out decimal monto))
                {
                    if (monto <= 0)
                    {
                        MessageBox.Show("El monto debe ser mayor a cero", "Monto Inválido",
                                      MessageBoxButton.OK, MessageBoxImage.Warning);
                        txtMontoCooperacion.Focus();
                        return;
                    }
                    montoCooperacion = monto;
                }
                else
                {
                    MessageBox.Show("El monto debe ser un número válido", "Monto Inválido",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    txtMontoCooperacion.Focus();
                    return;
                }
            }

            // Confirmar cambios
            var resultado = MessageBox.Show(
                $"¿Está seguro que desea guardar los cambios?\n\n" +
                $"Tarea ID: {_idTareaActual}\n" +
                $"Nuevo Título: {titulo}\n" +
                $"Tipo: {tipoTarea}",
                "Confirmar Modificación",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                ModificarTarea(_idTareaActual, titulo, descripcion, fechaLimite, tipoTarea, montoCooperacion);
            }
        }

        private void ModificarTarea(int idTarea, string titulo, string descripcion,
                                   DateTime fechaLimite, string tipoTarea, decimal? montoCooperacion)
        {
            try
            {
                bool modificado = _dataService.ModificarTarea(idTarea, titulo, descripcion,
                                                             fechaLimite, tipoTarea, montoCooperacion);

                if (modificado)
                {
                    MessageBox.Show("Tarea modificada exitosamente.", "Éxito",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Limpiar selección y recargar
                    dgTareas.SelectedItem = null;
                    OcultarFormulario();
                    txtBuscarTarea.Clear();
                    CargarTareas();
                }
                else
                {
                    MessageBox.Show("No se pudo modificar la tarea.", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar la tarea: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelarEdicion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show(
                "¿Desea cancelar la edición?\nLos cambios no guardados se perderán.",
                "Confirmar Cancelación",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
                menuWindow.Show();
                this.Close();
            }

        }

        private void LimpiarFormulario()
        {
            txtTitulo.Clear();
            txtDescripcion.Clear();
            dpFechaLimite.SelectedDate = null;
            cmbTipoTarea.SelectedIndex = -1;
            txtMontoCooperacion.Clear();
            gridMontoCooperacion.Visibility = Visibility.Collapsed;
            _idTareaActual = 0;
        }

        // Métodos de navegación del menú
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }
        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
        // Métodos de placeholder
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Ingrese el nombre de la tarea a buscar";
                textBox.Foreground = Brushes.Gray;
            }
        }
    }
}