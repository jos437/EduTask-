﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace eduTask.ventanas
{
    public partial class asignacionManual : Window
    {
        private DataService _dataService;
        private List<padreResumen> _todosPadres;
        private List<padreResumen> _padresSeleccionados;
        private List<TareaInfo> _todasTareas;
        private TareaInfo _tareaSeleccionada;

        public asignacionManual()
        {
            InitializeComponent();
            _dataService = new DataService();
            _padresSeleccionados = new List<padreResumen>();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Cargar datos iniciales
            CargarPadres();

            // Manejar evento de focus en el TextBox
            txtBuscarPadre.GotFocus += (s, e) =>
            {
                if (txtBuscarPadre.Text == "Buscar por nombre, alumno o teléfono...")
                {
                    txtBuscarPadre.Text = "";
                }
            };

            txtBuscarPadre.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtBuscarPadre.Text))
                {
                    txtBuscarPadre.Text = "Buscar por nombre, alumno o teléfono...";
                }
            };
        }

        private void CargarPadres()
        {
            try
            {
                _todosPadres = _dataService.ObtenerTodosLosPadresResumen();
                dgPadres.ItemsSource = _todosPadres;

                if (_todosPadres.Count == 0)
                {
                    MessageBox.Show("No hay padres registrados en el sistema.",
                                  "Sin Padres",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar padres: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtBuscarPadre_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_todosPadres == null || _todosPadres.Count == 0)
                return;

            string textoBusqueda = txtBuscarPadre.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(textoBusqueda) ||
                textoBusqueda == "buscar por nombre, alumno o teléfono...")
            {
                dgPadres.ItemsSource = _todosPadres;
            }
            else
            {
                var padresFiltrados = _todosPadres.Where(p =>
                    (p.Nombre != null && p.Nombre.ToLower().Contains(textoBusqueda)) ||
                    (p.Alumno != null && p.Alumno.ToLower().Contains(textoBusqueda)) ||
                    (p.Telefono != null && p.Telefono.ToLower().Contains(textoBusqueda))
                ).ToList();

                dgPadres.ItemsSource = padresFiltrados;
            }
        }

        private void dgPadres_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _padresSeleccionados = dgPadres.SelectedItems.Cast<padreResumen>().ToList();

            if (_padresSeleccionados.Count > 0)
            {
                // Mostrar sección de tareas
                gridTareas.Visibility = Visibility.Visible;
                txtPadresSeleccionados.Text = $" ({_padresSeleccionados.Count} padre{(_padresSeleccionados.Count > 1 ? "s" : "")} seleccionado{(_padresSeleccionados.Count > 1 ? "s" : "")})";

                // Cargar tareas disponibles
                if (_todasTareas == null)
                {
                    CargarTareas();
                }

                // Ocultar resumen
                gridResumen.Visibility = Visibility.Collapsed;
                btnAsignar.IsEnabled = false;
            }
            else
            {
                gridTareas.Visibility = Visibility.Collapsed;
                gridResumen.Visibility = Visibility.Collapsed;
                btnAsignar.IsEnabled = false;
            }
        }

        private void CargarTareas()
        {
            try
            {
                _todasTareas = _dataService.ObtenerTodasLasTareasDetalladas();
                dgTareasDisponibles.ItemsSource = _todasTareas;

                if (_todasTareas.Count == 0)
                {
                    MessageBox.Show("No hay tareas registradas en el sistema.",
                                  "Sin Tareas",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgTareasDisponibles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgTareasDisponibles.SelectedItem != null && _padresSeleccionados.Count > 0)
            {
                _tareaSeleccionada = dgTareasDisponibles.SelectedItem as TareaInfo;

                if (_tareaSeleccionada != null)
                {
                    MostrarResumen();
                }
            }
            else
            {
                gridResumen.Visibility = Visibility.Collapsed;
                btnAsignar.IsEnabled = false;
            }
        }

        private void MostrarResumen()
        {
            // Información de la tarea
            txtInfoTarea.Text = $"Título: {_tareaSeleccionada.Titulo}\n\n" +
                               $"Tipo: {_tareaSeleccionada.Tipo}\n\n" +
                               $"Fecha Límite: {_tareaSeleccionada.FechaLimite:dd/MM/yyyy}\n\n" +
                               $"Total de asignaciones a crear: {_padresSeleccionados.Count}";

            if (_tareaSeleccionada.MontoCooperacion.HasValue)
            {
                txtInfoTarea.Text += $"\n\n Monto: ${_tareaSeleccionada.MontoCooperacion.Value:F2}";
            }

            // Lista de padres seleccionados
            lstPadresResumen.ItemsSource = _padresSeleccionados;

            // Mostrar resumen y habilitar botón
            gridResumen.Visibility = Visibility.Visible;
            btnAsignar.IsEnabled = true;
        }

        private void btnLimpiarSeleccion_Click(object sender, RoutedEventArgs e)
        {
            dgPadres.SelectedItems.Clear();
            dgTareasDisponibles.SelectedItem = null;
            txtBuscarPadre.Text = "Buscar por nombre, alumno o teléfono...";

            gridTareas.Visibility = Visibility.Collapsed;
            gridResumen.Visibility = Visibility.Collapsed;
            btnAsignar.IsEnabled = false;

            _padresSeleccionados.Clear();
            _tareaSeleccionada = null;
        }

        private void btnAsignar_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null || _padresSeleccionados == null || _padresSeleccionados.Count == 0)
            {
                MessageBox.Show("No hay información suficiente para realizar la asignación.",
                              "Datos Incompletos",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                return;
            }

            // Verificar si algún padre ya tiene esta tarea asignada
            var padresConTareaYaAsignada = VerificarAsignacionesExistentes();

            string mensajeAdvertencia = "";
            if (padresConTareaYaAsignada.Count > 0)
            {
                mensajeAdvertencia = $"\n\n ADVERTENCIA:\n" +
                                   $"{padresConTareaYaAsignada.Count} padre(s) ya tienen esta tarea asignada.\n" +
                                   $"Se omitirán en la asignación.";
            }

            // Confirmar asignación
            var resultado = MessageBox.Show(
                $"¿Está seguro de asignar la tarea?\n\n" +
                $"Tarea: {_tareaSeleccionada.Titulo}\n" +
                $"Padres seleccionados: {_padresSeleccionados.Count}\n" +
                $"Asignaciones a crear: {_padresSeleccionados.Count - padresConTareaYaAsignada.Count}" +
                $"{mensajeAdvertencia}",
                "Confirmar Asignación Manual",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                RealizarAsignacion();
            }
        }

        private List<padreResumen> VerificarAsignacionesExistentes()
        {
            List<padreResumen> padresConAsignacion = new List<padreResumen>();

            foreach (var padre in _padresSeleccionados)
            {
                if (_dataService.PadreTieneTareaAsignada(padre.IdPadre, _tareaSeleccionada.IdTarea))
                {
                    padresConAsignacion.Add(padre);
                }
            }

            return padresConAsignacion;
        }

        private void RealizarAsignacion()
        {
            try
            {
                int exitosas = 0;
                int fallidas = 0;
                int omitidas = 0;

                foreach (var padre in _padresSeleccionados)
                {
                    try
                    {
                        // Verificar si ya tiene esta tarea
                        if (_dataService.PadreTieneTareaAsignada(padre.IdPadre, _tareaSeleccionada.IdTarea))
                        {
                            omitidas++;
                            continue;
                        }

                        bool asignado = _dataService.AsignarTareaAPadre(
                            _tareaSeleccionada.IdTarea,
                            padre.IdPadre,
                            DateTime.Now
                        );

                        if (asignado)
                            exitosas++;
                        else
                            fallidas++;
                    }
                    catch (Exception)
                    {
                        fallidas++;
                    }
                }

                // Limpiar formulario solo si hubo asignaciones exitosas
                if (exitosas > 0)
                {
                    LimpiarFormulario();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error general al realizar la asignación: {ex.Message}",
                              "Error Crítico", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void LimpiarFormulario()
        {
            dgPadres.SelectedItems.Clear();
            dgTareasDisponibles.SelectedItem = null;
            lstPadresResumen.ItemsSource = null;
            txtInfoTarea.Text = string.Empty;
            txtBuscarPadre.Text = "Buscar por nombre, alumno o teléfono...";

            gridTareas.Visibility = Visibility.Collapsed;
            gridResumen.Visibility = Visibility.Collapsed;

            btnAsignar.IsEnabled = false;

            _padresSeleccionados.Clear();
            _tareaSeleccionada = null;

            // Recargar datos
            CargarPadres();
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
            menuWindow.Show();
            this.Close();
        }

        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agrerPadreWindow = new agrepaPrint();
            agrerPadreWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modpadresWindow = new modificarPadres();
            modpadresWindow.Show();
            this.Close();

        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }
        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            //tarea actual
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }
        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}
