﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace eduTask.ventanas
{
    public partial class asigAutomatica : Window
    {
        private DataService _dataService;
        private List<TareaInfo> _tareasSinAsignar;
        private TareaInfo _tareaSeleccionada;
        private List<padreResumen> _padresParaAsignar;

        public asigAutomatica()
        {
            InitializeComponent();
            _dataService = new DataService();
            InicializarControles();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Cargar tareas sin asignaciones
            CargarTareasSinAsignaciones();
        }

        private void InicializarControles()
        {
            // Asegurar que los controles estén en un estado inicial seguro
            if (gridOpciones != null)
                gridOpciones.Visibility = Visibility.Collapsed;

            if (gridResumen != null)
                gridResumen.Visibility = Visibility.Collapsed;

            if (btnGenerarResumen != null)
                btnGenerarResumen.IsEnabled = false;

            if (btnAsignar != null)
                btnAsignar.IsEnabled = false;

            if (rbAsignarATodos != null)
                rbAsignarATodos.IsChecked = true;
        }
        private void CargarTareasSinAsignaciones()
        {
            try
            {
                _tareasSinAsignar = _dataService.ObtenerTareasSinAsignaciones();

                if (dgTareasSinAsignar != null)
                    dgTareasSinAsignar.ItemsSource = _tareasSinAsignar;

                if (_tareasSinAsignar.Count == 0)
                {
                    MessageBox.Show("No hay tareas disponibles sin asignaciones.\n\n" +
                                  "Todas las tareas ya tienen asignaciones activas.",
                                  "Sin Tareas Disponibles",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgTareasSinAsignar_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (dgTareasSinAsignar?.SelectedItem != null)
                {
                    _tareaSeleccionada = dgTareasSinAsignar.SelectedItem as TareaInfo;

                    if (_tareaSeleccionada != null)
                    {
                        // Mostrar opciones de asignación
                        if (gridOpciones != null)
                            gridOpciones.Visibility = Visibility.Visible;

                        if (btnGenerarResumen != null)
                            btnGenerarResumen.IsEnabled = true;

                        // Ocultar resumen hasta que se genere
                        if (gridResumen != null)
                            gridResumen.Visibility = Visibility.Collapsed;

                        if (btnAsignar != null)
                            btnAsignar.IsEnabled = false;
                    }
                }
                else
                {
                    if (gridOpciones != null)
                        gridOpciones.Visibility = Visibility.Collapsed;

                    if (gridResumen != null)
                        gridResumen.Visibility = Visibility.Collapsed;

                    if (btnGenerarResumen != null)
                        btnGenerarResumen.IsEnabled = false;

                    if (btnAsignar != null)
                        btnAsignar.IsEnabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al seleccionar tarea: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TipoAsignacion_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                // Ocultar resumen cuando cambien el tipo
                if (gridResumen != null)
                    gridResumen.Visibility = Visibility.Collapsed;

                if (btnAsignar != null)
                    btnAsignar.IsEnabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cambiar tipo de asignación: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void btnGenerarResumen_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea primero.", "Tarea no Seleccionada",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Obtener padres según el tipo de asignación
                if (rbAsignarATodos.IsChecked == true)
                {
                    _padresParaAsignar = _dataService.ObtenerTodosLosPadresResumen();
                }
                else
                {
                    _padresParaAsignar = _dataService.ObtenerPadresSinTareasActivas();
                }

                if (_padresParaAsignar.Count == 0)
                {
                    MessageBox.Show("No hay padres disponibles con los criterios seleccionados.",
                                  "Sin Padres Disponibles",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                    return;
                }

                // Mostrar resumen
                MostrarResumen();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al generar resumen: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MostrarResumen()
        {
            // Información de la tarea
            string tipoAsignacion = rbAsignarATodos.IsChecked == true
                ? "TODOS los padres"
                : "Padres SIN tareas activas";

            txtInfoTarea.Text = $"Tarea: {_tareaSeleccionada.Titulo}\n" +
                               $"Tipo: {_tareaSeleccionada.Tipo}\n" +
                               $"Fecha Límite: {_tareaSeleccionada.FechaLimite:dd/MM/yyyy}\n" +
                               $"Se asignará a: {tipoAsignacion}\n" +
                               $"Total de asignaciones a crear: {_padresParaAsignar.Count}";

            // Mostrar lista de padres
            dgResumenPadres.ItemsSource = _padresParaAsignar;

            // Mostrar el resumen y habilitar botón de asignar
            gridResumen.Visibility = Visibility.Visible;
            btnAsignar.IsEnabled = true;
        }

        private void btnAsignar_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null || _padresParaAsignar == null || _padresParaAsignar.Count == 0)
            {
                MessageBox.Show("No hay información suficiente para realizar la asignación.",
                              "Datos Incompletos",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                return;
            }

            // Confirmar asignación
            var resultado = MessageBox.Show(
                $"¿Está seguro de asignar la tarea?\n\n" +
                $"Tarea: {_tareaSeleccionada.Titulo}\n" +
                $"Total de asignaciones: {_padresParaAsignar.Count}\n\n" +
                $"Esta acción creará {_padresParaAsignar.Count} nuevas asignaciones.",
                "Confirmar Asignación Automática",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                RealizarAsignacion();
            }
        }

        private void RealizarAsignacion()
        {
            try
            {
                int exitosas = 0;
                int fallidas = 0;
                List<string> errores = new List<string>();

                foreach (var padre in _padresParaAsignar)
                {
                    try
                    {
                        bool asignado = _dataService.AsignarTareaAPadre(
                            _tareaSeleccionada.IdTarea,
                            padre.IdPadre,
                            DateTime.Now);

                        if (asignado)
                            exitosas++;
                        else
                        {
                            fallidas++;
                            errores.Add($"Padre: {padre.Nombre} (ID: {padre.IdPadre})");
                        }
                    }
                    catch (Exception ex)
                    {
                        fallidas++;
                        errores.Add($"Padre: {padre.Nombre} - Error: {ex.Message}");
                    }
                }

                string mensaje = $"Asignación completada\n\n" +
                               $"Exitosas: {exitosas}\n" +
                               $"Fallidas: {fallidas}";

                if (fallidas > 0)
                {
                    mensaje += $"\n\n Errores encontrados:\n{string.Join("\n", errores.Take(5))}";
                    if (errores.Count > 5)
                        mensaje += $"\n... y {errores.Count - 5} más";
                }

                MessageBoxImage icono = fallidas == 0
                    ? MessageBoxImage.Information
                    : MessageBoxImage.Warning;

                MessageBox.Show(mensaje, "Resultado de Asignación", MessageBoxButton.OK, icono);

                if (exitosas > 0)
                {
               
                    LimpiarFormulario();
                    CargarTareasSinAsignaciones();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al realizar la asignación: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LimpiarFormulario()
        {
            dgTareasSinAsignar.SelectedItem = null;
            dgResumenPadres.ItemsSource = null;
            txtInfoTarea.Text = string.Empty;

            gridOpciones.Visibility = Visibility.Collapsed;
            gridResumen.Visibility = Visibility.Collapsed;

            btnGenerarResumen.IsEnabled = false;
            btnAsignar.IsEnabled = false;

            rbAsignarATodos.IsChecked = true;

            _tareaSeleccionada = null;
            _padresParaAsignar = null;
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
            menuWindow.Show();
            this.Close();
        }

        // Métodos de navegación del menú
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarPadreWindow = new agrepaPrint();
            agregarPadreWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarPadres = new modificarPadres();
            modificarPadres.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            //vanteana actual
        }
        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}