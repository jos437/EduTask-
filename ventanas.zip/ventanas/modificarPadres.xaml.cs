﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class modificarPadres : Window
    {
        private DataService _dataService;
        private Padre _padreActual;

        public modificarPadres()
        {
            InitializeComponent();
            _dataService = new DataService();
            ConfigurarPlaceholders();
        }

        private void ConfigurarPlaceholders()
        {
            txtBusqueda.Text = "Ingrese el nombre a buscar";
            txtBusqueda.Foreground = Brushes.Gray;
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            string nombreBuscar = txtBusqueda.Text.Trim();
            if (nombreBuscar == "Ingrese nombre a buscar" || string.IsNullOrWhiteSpace(nombreBuscar))
            {
                MessageBox.Show("Ingrese un nombre para buscar", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Buscar padres por nombre (coincidencia parcial)
                var padres = _dataService.BuscarPadresPorNombre(nombreBuscar);

                if (padres == null || padres.Count == 0)
                {
                    MessageBox.Show("No se encontró ningún padre con ese nombre", "Búsqueda",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    formModificar.Visibility = Visibility.Collapsed;
                    txtMensaje.Visibility = Visibility.Visible;
                    txtMensaje.Text = "No se encontró ningún padre con ese nombre. Intente con otro nombre.";
                    return;
                }

                Padre padreSeleccionado;

                // Si hay múltiples resultados, mostrar para seleccionar
                if (padres.Count > 1)
                {
                    string opciones = "Se encontraron varios padres:\n\n";
                    for (int i = 0; i < padres.Count; i++)
                    {
                        opciones += $"{i + 1}. {padres[i].Nombre} - Alumno: {padres[i].Alumno ?? "N/A"}\n";
                    }
                    opciones += "\nSe seleccionará el primer resultado. Para mayor precisión, sea más específico.";

                    MessageBox.Show(opciones, "Múltiples Resultados",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Seleccionar el primero
                    padreSeleccionado = padres[0];
                }
                else
                {
                    // Si solo hay un resultado, seleccionarlo directamente
                    padreSeleccionado = padres[0];
                }

                // Guardar el padre actual
                _padreActual = padreSeleccionado;

                // Llenar el formulario con los datos encontrados
                txtNombre.Text = _padreActual.Nombre;
                txtTelefono.Text = _padreActual.Contacto ?? "";
                txtnomAlumno.Text = _padreActual.Alumno ?? "";
                txtComentarios.Text = _padreActual.Comentario ?? "";

                // Mostrar formulario y ocultar mensaje
                formModificar.Visibility = Visibility.Visible;
                txtMensaje.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar padre: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void btnActualizar_Click(object sender, RoutedEventArgs e)
        {
            if (_padreActual == null)
            {
                MessageBox.Show("Primero debe buscar un padre para modificar", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("El nombre es obligatorio", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtNombre.Focus();
                return;
            }

            // Verificar si el nombre fue cambiado y si ya existe otro padre con ese nombre
            string nuevoNombre = txtNombre.Text.Trim();
            if (nuevoNombre != _padreActual.Nombre && _dataService.ExistePadre(nuevoNombre))
            {
                MessageBox.Show("Ya existe otro padre registrado con este nombre", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtNombre.Focus();
                return;
            }

            // Actualizar los datos del padre
            _padreActual.Nombre = nuevoNombre;
            _padreActual.Contacto = string.IsNullOrWhiteSpace(txtTelefono.Text) ? null : txtTelefono.Text.Trim();
            _padreActual.Alumno = string.IsNullOrWhiteSpace(txtnomAlumno.Text) ? null : txtnomAlumno.Text.Trim();
            _padreActual.Comentario = string.IsNullOrWhiteSpace(txtComentarios.Text) ? null : txtComentarios.Text.Trim();

            bool resultado = _dataService.ActualizarPadre(_padreActual);

            if (resultado)
            {
                MessageBox.Show("Datos del padre actualizados exitosamente", "Éxito",
                              MessageBoxButton.OK, MessageBoxImage.Information);
                LimpiarFormulario();
            }
            else
            {
                MessageBox.Show("Error al actualizar los datos del padre", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cancelar? Los cambios no guardados se perderán.",
                                          "Confirmar Cancelación",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
                menuWindow.Show();
                this.Close();
            }
        }

        private void LimpiarFormulario()
        {
            txtBusqueda.Text = "Ingrese nombre a buscar";
            txtBusqueda.Foreground = Brushes.Gray;

            txtNombre.Text = "";
            txtTelefono.Text = "";
            txtnomAlumno.Text = "";
            txtComentarios.Text = "";

            formModificar.Visibility = Visibility.Collapsed;
            txtMensaje.Visibility = Visibility.Visible;
            txtMensaje.Text = "Ingrese el nombre del padre que desea modificar";

            _padreActual = null;
            txtBusqueda.Focus();
        }

        // Métodos de placeholder para el campo de búsqueda
        private void txtBuscarNombre_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void txtBuscarNombre_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Ingrese nombre a buscar";
                textBox.Foreground = Brushes.Gray;
            }
        }

        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            // Ventana actual
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }
        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                // Restaurar el placeholder según el TextBox
                if (textBox.Name == "txtBusqueda")
                    textBox.Text = "Ingrese nombre a buscar";

                textBox.Foreground = Brushes.Gray;
            }
        }
    }
}