﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class eliminarPrint : Window
    {
        private DataService _dataService;
        private Padre _padreActual;

        public eliminarPrint()
        {
            InitializeComponent();
            _dataService = new DataService();
            ConfigurarPlaceholders();
        }

        private void ConfigurarPlaceholders()
        {
            txtBusqueda.Text = "Ingrese nombre a buscar";
            txtBusqueda.Foreground = Brushes.Gray;
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            string nombreBuscar = txtBusqueda.Text.Trim();
            if (nombreBuscar == "Ingrese nombre a buscar" || string.IsNullOrWhiteSpace(nombreBuscar))
            {
                MessageBox.Show("Ingrese un nombre para buscar", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Buscar padres por nombre (coincidencia parcial)
                var padres = _dataService.BuscarPadresPorNombre(nombreBuscar);

                if (padres == null || padres.Count == 0)
                {
                    MessageBox.Show("No se encontró ningún padre con ese nombre", "Búsqueda",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    formEliminar.Visibility = Visibility.Collapsed;
                    txtMensaje.Visibility = Visibility.Visible;
                    txtMensaje.Text = "No se encontró ningún padre con ese nombre. Intente con otro nombre.";
                    return;
                }

                Padre padreSeleccionado;

                // Si hay múltiples resultados, mostrar para seleccionar
                if (padres.Count > 1)
                {
                    string opciones = "Se encontraron varios padres:\n\n";
                    for (int i = 0; i < padres.Count; i++)
                    {
                        opciones += $"{i + 1}. {padres[i].Nombre} - Alumno: {padres[i].Alumno ?? "N/A"}\n";
                    }
                    opciones += "\nSe seleccionará el primer resultado. Para mayor precisión, sea más específico.";

                    MessageBox.Show(opciones, "Múltiples Resultados",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Seleccionar el primero
                    padreSeleccionado = padres[0];
                }
                else
                {
                    // Si solo hay un resultado, seleccionarlo directamente
                    padreSeleccionado = padres[0];
                }

                // Guardar el padre actual para uso posterior (eliminación, etc.)
                _padreActual = padreSeleccionado;

                // Mostrar la información del padre encontrado
                txtNombre.Text = padreSeleccionado.Nombre;
                txtTelefono.Text = padreSeleccionado.Contacto ?? "No especificado";
                txtnomAlumno.Text = padreSeleccionado.Alumno ?? "No especificado";
                txtComentarios.Text = padreSeleccionado.Comentario ?? "No hay comentarios";

                // Mostrar formulario de eliminación y ocultar mensaje
                formEliminar.Visibility = Visibility.Visible;
                txtMensaje.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar padre: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            if (_padreActual == null)
            {
                MessageBox.Show("Primero debe buscar un padre para eliminar", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Confirmación adicional por seguridad
            var resultado = MessageBox.Show(
                $"¿Está completamente seguro que desea eliminar al padre '{_padreActual.Nombre}'?\n\nEsta acción es PERMANENTE y no se puede deshacer.",
                "Confirmar Eliminación",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (resultado == MessageBoxResult.Yes)
            {
                bool eliminado = _dataService.EliminarPadre(_padreActual.IdPadre);

                if (eliminado)
                {
                    MessageBox.Show($"Padre '{_padreActual.Nombre}' eliminado exitosamente", "Éxito",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarFormulario();
                }
                else
                {
                    MessageBox.Show("Error al eliminar el padre", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cancelar?",
                                          "Confirmar Cancelación",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
                menuWindow.Show();
                this.Close();
            }
        }

        private void LimpiarFormulario()
        {
            txtBusqueda.Text = "Ingrese nombre a buscar";
            txtBusqueda.Foreground = Brushes.Gray;

            txtNombre.Text = "";
            txtTelefono.Text = "";
            txtnomAlumno.Text = "";
            txtComentarios.Text = "";

            formEliminar.Visibility = Visibility.Collapsed;
            txtMensaje.Visibility = Visibility.Visible;
            txtMensaje.Text = "Ingrese el nombre del padre que desea eliminar";

            _padreActual = null;
            txtBusqueda.Focus();
        }

        // Métodos de placeholder
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Ingrese nombre a buscar";
                textBox.Foreground = Brushes.Gray;
            }
        }
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            // Ventana actual
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }
        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }
        
        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

    }
}
