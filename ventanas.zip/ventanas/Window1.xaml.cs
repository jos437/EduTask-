﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using eduTask.Modelos;

namespace eduTask.ventanas
{
    public partial class Window1 : Window
    {
        private Usuario _usuarioActual;
        public Window1(Usuario usuarioActual)
        {
            InitializeComponent();
            _usuarioActual = usuarioActual;
            InitializedWindow1();

        }

        private void InitializedWindow1()
        {
            Title = $"Bienvenida al Sistema de Gestión de Tareas, {_usuarioActual.Nombre}";
        }
    }
}
