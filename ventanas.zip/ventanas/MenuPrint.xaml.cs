﻿using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace eduTask.ventanas
{
    public partial class MenuPrint : Window
    {
        private Usuario _usuarioActual;

        public MenuPrint(Usuario usuario)
        {
            InitializeComponent();
            _usuarioActual = usuario;
            CargarDatosUsuario();
        }

        private void CargarDatosUsuario()
        {
            if (_usuarioActual != null)
            {
                txtnombreUsuario.Text = _usuarioActual.Nombre;
                Title = $"Sistema de Gestión Educativa - {_usuarioActual.Nombre}";
            }
        }
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agrerPadreWindow = new agrepaPrint();
            agrerPadreWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modpadresWindow = new modificarPadres();
            modpadresWindow.Show();
            this.Close();
           
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }
        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detallesTareaWindow = new detallesTarea();
            detallesTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }
        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}