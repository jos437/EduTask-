﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class detallesCooperacion : Window
    {
        private DataService _dataService;
        private List<CooperacionDetalle> _todasCooperaciones;
        private List<CooperacionDetalle> _cooperacionesFiltradas;
        private int? _idAsignacionInicial;
        private CooperacionDetalle _cooperacionSeleccionada; 

        public detallesCooperacion()
        {
            InitializeComponent();
            _dataService = new DataService();
            InicializarVentana();
        }

        public detallesCooperacion(int idAsignacion)
        {
            InitializeComponent();
            _idAsignacionInicial = idAsignacion;
            InicializarVentana();
        }

        private void InicializarVentana()
        {
            InitializeComponent();
            _dataService = new DataService();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Configurar TextBox de búsqueda
            txtBuscar.GotFocus += (s, e) =>
            {
                if (txtBuscar.Text == "Buscar por padre o tarea...")
                    txtBuscar.Text = "";
            };

            txtBuscar.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtBuscar.Text))
                    txtBuscar.Text = "Buscar por padre o tarea...";
            };

            dgCooperaciones.SelectionChanged += dgCooperaciones_SelectionChanged;

            // Cargar datos
            CargarCooperaciones();

            if (_idAsignacionInicial.HasValue)
            {
                // Usar Dispatcher para asegurar que el DataGrid esté completamente cargado
                this.Dispatcher.InvokeAsync(() =>
                {
                    SeleccionarYEnfocarCooperacion(_idAsignacionInicial.Value);
                }, System.Windows.Threading.DispatcherPriority.Loaded);
            }
        }
        private void dgCooperaciones_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgCooperaciones.SelectedItem != null)
            {
                _cooperacionSeleccionada = (CooperacionDetalle)dgCooperaciones.SelectedItem;
            }
            else
            {
                _cooperacionSeleccionada = null;
            }
        }

        private void CargarCooperaciones()
        {
            try
            {
                _todasCooperaciones = _dataService.ObtenerTodasLasCooperaciones();
                _cooperacionesFiltradas = _todasCooperaciones;
                dgCooperaciones.ItemsSource = _cooperacionesFiltradas;

                ActualizarEstadisticas();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar cooperaciones: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ActualizarEstadisticas()
        {
            if (_cooperacionesFiltradas == null || _cooperacionesFiltradas.Count == 0)
            {
                txtTotalRecaudar.Text = "$0.00";
                txtRecaudado.Text = "$0.00";
                txtPendiente.Text = "$0.00";
                txtPorcentaje.Text = "0%";
                return;
            }

            decimal totalRecaudar = _cooperacionesFiltradas.Sum(c => c.Monto);
            decimal recaudado = _cooperacionesFiltradas.Sum(c => c.CantidadPagada);
            decimal pendiente = totalRecaudar - recaudado;
            double porcentaje = totalRecaudar > 0 ? (double)(recaudado / totalRecaudar * 100) : 0;

            txtTotalRecaudar.Text = $"${totalRecaudar:F2}";
            txtRecaudado.Text = $"${recaudado:F2}";
            txtPendiente.Text = $"${pendiente:F2}";
            txtPorcentaje.Text = $"{porcentaje:F1}%";
        }

        private void AplicarFiltros()
        {
            if (_todasCooperaciones == null || _todasCooperaciones.Count == 0)
                return;

            string textoBusqueda = txtBuscar.Text.Trim().ToLower();
            string filtroEstado = (cmbFiltroEstado.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Todas";

            _cooperacionesFiltradas = _todasCooperaciones.Where(c =>
            {
                // Filtro de búsqueda
                bool cumpleBusqueda = string.IsNullOrWhiteSpace(textoBusqueda) ||
                                     textoBusqueda == "buscar por padre o tarea..." ||
                                     (c.NombreTarea != null && c.NombreTarea.ToLower().Contains(textoBusqueda)) ||
                                     (c.NombrePadre != null && c.NombrePadre.ToLower().Contains(textoBusqueda)) ||
                                     (c.NombreAlumno != null && c.NombreAlumno.ToLower().Contains(textoBusqueda));

                // Filtro de estado
                bool cumpleEstado = filtroEstado == "Todas" ||
                                   (c.Estado != null && c.Estado.Equals(filtroEstado.Replace("s", ""), StringComparison.OrdinalIgnoreCase));

                return cumpleBusqueda && cumpleEstado;
            }).ToList();

            dgCooperaciones.ItemsSource = _cooperacionesFiltradas;
            ActualizarEstadisticas();
        }

        private void txtBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            AplicarFiltros();
        }

        private void cmbFiltroEstado_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            AplicarFiltros();
        }

        private void btnLimpiar_Click(object sender, RoutedEventArgs e)
        {
            txtBuscar.Text = "Buscar por padre o tarea...";
            cmbFiltroEstado.SelectedIndex = 0;
            AplicarFiltros();
        }

        private void btnExportarCooperaciones_Click(object sender, RoutedEventArgs e)
        {
            if (_cooperacionesFiltradas == null || _cooperacionesFiltradas.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.", "Sin Datos",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var saveDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "Archivo Excel|*.xlsx",
                    FileName = $"Cooperaciones_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    bool exportado = _dataService.ExportarCooperaciones(_cooperacionesFiltradas, saveDialog.FileName);

                    if (exportado)
                    {
                        var resultado = MessageBox.Show(
                            "Exportación completada exitosamente.\n\n" +
                            $"Archivo: {System.IO.Path.GetFileName(saveDialog.FileName)}\n\n" +
                            "¿Desea abrir el archivo?",
                            "Exportación Exitosa",
                            MessageBoxButton.YesNo,
                            MessageBoxImage.Information);

                        if (resultado == MessageBoxResult.Yes)
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                            {
                                FileName = saveDialog.FileName,
                                UseShellExecute = true
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al exportar: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnMarcarIncumplida_Click(object sender, RoutedEventArgs e)
        {
            if (_cooperacionSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea de la tabla.",
                              "Sin Selección", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Mostrar panel de penalización
            borderPenalizacion.Visibility = Visibility.Visible;
            txtPenalizacion.Text = "Describa la penalización...";
            txtPenalizacion.Focus();
        }

        private void btnConfirmarIncumplida_Click(object sender, RoutedEventArgs e)
        {
            if (_cooperacionSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea de la tabla.",
                              "Sin Selección", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string penalizacion = txtPenalizacion.Text.Trim();

            if (string.IsNullOrWhiteSpace(penalizacion) || penalizacion == "Describa la penalización...")
            {
                MessageBox.Show("Por favor describa la penalización antes de continuar.",
                              "Campo Vacío", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var resultado = MessageBox.Show(
                $"¿Está seguro de marcar como INCUMPLIDA la tarea?\n\n" +
                $"Tarea: {_cooperacionSeleccionada.NombreTarea}\n" +
                $"Padre: {_cooperacionSeleccionada.NombrePadre}\n" +
                $"Alumno: {_cooperacionSeleccionada.NombreAlumno}\n\n" +
                $"Penalización: {penalizacion}",
                "Confirmar Incumplida",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (resultado == MessageBoxResult.Yes)
            {
                try
                {
                    bool actualizado = _dataService.ActualizarEstadoTarea(
                        _cooperacionSeleccionada.IdAsignacion,
                        "incumplida",
                        penalizacion);

                    if (actualizado)
                    {
                        MessageBox.Show("Tarea marcada como INCUMPLIDA exitosamente.",
                                      "Éxito", MessageBoxButton.OK, MessageBoxImage.Information);


                        borderPenalizacion.Visibility = Visibility.Collapsed;
                        txtPenalizacion.Text = "Describa la penalización...";
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el estado de la tarea.",
                                      "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar tarea: {ex.Message}", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnRegistrarAnticipo_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag != null)
            {
                int idAsignacion = Convert.ToInt32(btn.Tag);
                var cooperacion = _cooperacionesFiltradas.FirstOrDefault(c => c.IdAsignacion == idAsignacion);

                if (cooperacion != null)
                {
                    // Crear ventana de diálogo para el anticipo
                    Window dialogoAnticipo = new Window
                    {
                        Title = "Registrar Anticipo",
                        Width = 450,
                        Height = 500,
                        WindowStartupLocation = WindowStartupLocation.CenterScreen,
                        ResizeMode = ResizeMode.NoResize,
                        Background = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FFFFF8F8"))
                    };

                    Grid grid = new Grid();
                    grid.Margin = new Thickness(20);

                    // Definir filas
                    for (int i = 0; i < 6; i++)
                    {
                        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                    }

                    // Título
                    TextBlock titulo = new TextBlock
                    {
                        Text = "Registrar Anticipo de Cooperación",
                        FontSize = 16,
                        FontWeight = FontWeights.Bold,
                        Foreground = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FFFF9800")),
                        Margin = new Thickness(0, 0, 0, 15),
                        TextAlignment = TextAlignment.Center
                    };
                    Grid.SetRow(titulo, 0);
                    grid.Children.Add(titulo);

                    // Información de la cooperación
                    Border borderInfo = new Border
                    {
                        Background = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FFFEF5E7")),
                        BorderBrush = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FFFF9800")),
                        BorderThickness = new Thickness(2),
                        CornerRadius = new System.Windows.CornerRadius(5),
                        Padding = new Thickness(15),
                        Margin = new Thickness(0, 0, 0, 20)
                    };

                    TextBlock info = new TextBlock
                    {
                        Text = $"Tarea: {cooperacion.NombreTarea}\n" +
                               $"Padre: {cooperacion.NombrePadre}\n" +
                               $"Alumno: {cooperacion.NombreAlumno}\n\n" +
                               $"Monto Total: ${cooperacion.Monto:F2}\n" +
                               $"Pagado: ${cooperacion.CantidadPagada:F2}\n" +
                               $"Restante: ${cooperacion.MontoRestante:F2}",
                        FontSize = 12,
                        LineHeight = 22
                    };

                    borderInfo.Child = info;
                    Grid.SetRow(borderInfo, 1);
                    grid.Children.Add(borderInfo);

                    // Label Anticipo
                    TextBlock lblAnticipo = new TextBlock
                    {
                        Text = "Cantidad del Anticipo:",
                        FontSize = 13,
                        FontWeight = FontWeights.Bold,
                        Foreground = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FFFF9800")),
                        Margin = new Thickness(0, 0, 0, 8)
                    };
                    Grid.SetRow(lblAnticipo, 2);
                    grid.Children.Add(lblAnticipo);

                    // TextBox para el anticipo
                    TextBox txtAnticipo = new TextBox
                    {
                        FontSize = 13,
                        Padding = new Thickness(10),
                        BorderThickness = new Thickness(2),
                        BorderBrush = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FFFF9800")),
                        Margin = new Thickness(0, 0, 0, 20),
                        Height = 40
                    };

                    // Placeholder para el TextBox
                    txtAnticipo.GotFocus += (s, ev) =>
                    {
                        if (txtAnticipo.Foreground == System.Windows.Media.Brushes.Gray)
                        {
                            txtAnticipo.Text = "";
                            txtAnticipo.Foreground = System.Windows.Media.Brushes.Black;
                        }
                    };

                    txtAnticipo.LostFocus += (s, ev) =>
                    {
                        if (string.IsNullOrWhiteSpace(txtAnticipo.Text))
                        {
                            txtAnticipo.Text = "0.00";
                            txtAnticipo.Foreground = System.Windows.Media.Brushes.Gray;
                        }
                    };

                    txtAnticipo.Text = "0.00";
                    txtAnticipo.Foreground = System.Windows.Media.Brushes.Gray;

                    Grid.SetRow(txtAnticipo, 3);
                    grid.Children.Add(txtAnticipo);

                    // Panel de botones
                    StackPanel panelBotones = new StackPanel
                    {
                        Orientation = Orientation.Horizontal,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 10, 0, 0)
                    };

                    Button btnConfirmar = new Button
                    {
                        Content = "CONFIRMAR",
                        Width = 140,
                        Height = 40,
                        Margin = new Thickness(0, 0, 10, 0),
                        Background = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FF4CAF50")),
                        Foreground = System.Windows.Media.Brushes.White,
                        FontWeight = FontWeights.Bold,
                        FontSize = 12,
                        Cursor = System.Windows.Input.Cursors.Hand,
                        BorderThickness = new Thickness(0)
                    };

                    Button btnCancelar = new Button
                    {
                        Content = "CANCELAR",
                        Width = 140,
                        Height = 40,
                        Background = new System.Windows.Media.SolidColorBrush(
                            (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#FF6C757D")),
                        Foreground = System.Windows.Media.Brushes.White,
                        FontWeight = FontWeights.Bold,
                        FontSize = 12,
                        Cursor = System.Windows.Input.Cursors.Hand,
                        BorderThickness = new Thickness(0)
                    };

                    btnConfirmar.Click += (s, ev) =>
                    {
                        string textoAnticipo = txtAnticipo.Text.Trim();

                        if (decimal.TryParse(textoAnticipo, out decimal anticipo))
                        {
                            if (anticipo <= 0)
                            {
                                MessageBox.Show("El anticipo debe ser mayor a cero.", "Monto Inválido",
                                              MessageBoxButton.OK, MessageBoxImage.Warning);
                                txtAnticipo.Focus();
                                return;
                            }

                            decimal nuevoTotal = cooperacion.CantidadPagada + anticipo;

                            if (nuevoTotal > cooperacion.Monto)
                            {
                                MessageBox.Show(
                                    $"El anticipo excede el monto restante.\n\n" +
                                    $"Monto restante: ${cooperacion.MontoRestante:F2}\n" +
                                    $"Anticipo ingresado: ${anticipo:F2}\n" +
                                    $"Exceso: ${(nuevoTotal - cooperacion.Monto):F2}",
                                    "Monto Excedido",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Warning);
                                txtAnticipo.Focus();
                                return;
                            }

                            var resultado = MessageBox.Show(
                                $"¿Confirmar registro de anticipo?\n\n" +
                                $"Anticipo: ${anticipo:F2}\n\n" +
                                $"Pagado actual: ${cooperacion.CantidadPagada:F2}\n" +
                                $"Nuevo total pagado: ${nuevoTotal:F2}\n" +
                                $"Restante: ${(cooperacion.Monto - nuevoTotal):F2}\n\n" +
                                $"{(nuevoTotal >= cooperacion.Monto ? "LA COOPERACIÓN SE COMPLETARÁ" : "AÚN QUEDARÍA PENDIENTE")}",
                                "Confirmar Anticipo",
                                MessageBoxButton.YesNo,
                                MessageBoxImage.Question);

                            if (resultado == MessageBoxResult.Yes)
                            {
                                try
                                {
                                    bool actualizado = _dataService.RegistrarAnticipoCooperacion(
                                        idAsignacion,
                                        anticipo);

                                    if (actualizado)
                                    {
                                        MessageBox.Show(
                                            $"Anticipo registrado exitosamente.\n\n" +
                                            $"Anticipo: ${anticipo:F2}\n" +
                                            $"Nuevo total pagado: ${nuevoTotal:F2}",
                                            "Éxito",
                                            MessageBoxButton.OK,
                                            MessageBoxImage.Information);

                                        dialogoAnticipo.Close();
                                        CargarCooperaciones();
                                    }
                                    else
                                    {
                                        MessageBox.Show("No se pudo registrar el anticipo.",
                                                      "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show($"Error al registrar anticipo:\n{ex.Message}", "Error",
                                                  MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Por favor ingrese un monto válido.\n\nEjemplo: 150.00",
                                          "Formato Inválido",
                                          MessageBoxButton.OK,
                                          MessageBoxImage.Warning);
                            txtAnticipo.Focus();
                        }
                    };

                    btnCancelar.Click += (s, ev) => dialogoAnticipo.Close();

                    panelBotones.Children.Add(btnConfirmar);
                    panelBotones.Children.Add(btnCancelar);

                    Grid.SetRow(panelBotones, 4);
                    grid.Children.Add(panelBotones);

                    dialogoAnticipo.Content = grid;
                    dialogoAnticipo.ShowDialog();
                }
            }
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                // Restaurar el placeholder según el TextBox
                if (textBox.Name == "txtPenalizacion")
                    textBox.Text = "Describa la penalización...";

                textBox.Foreground = Brushes.Gray;
            }
        }

        // ✅ MÉTODO NUEVO: Seleccionar y enfocar una cooperación específica
        private void SeleccionarYEnfocarCooperacion(int idAsignacion)
        {
            try
            {
                Debug.WriteLine($"DEBUG - Buscando cooperación con idAsignacion: {idAsignacion}");

                // Buscar la cooperación en la lista
                var cooperacion = _cooperacionesFiltradas?.FirstOrDefault(c => c.IdAsignacion == idAsignacion);

                if (cooperacion != null)
                {
                    Debug.WriteLine($"DEBUG - Cooperación encontrada: {cooperacion.NombreTarea}");

                    // Seleccionar la fila en el DataGrid
                    dgCooperaciones.SelectedItem = cooperacion;
                    _cooperacionSeleccionada = cooperacion;

                    // Hacer scroll hasta la fila seleccionada
                    dgCooperaciones.ScrollIntoView(cooperacion);

                    // Establecer el foco en el DataGrid
                    dgCooperaciones.Focus();

                    // Resaltar visualmente con un mensaje
                    MessageBox.Show(
                        $"Mostrando detalles de la cooperación:\n\n" +
                        $"Tarea: {cooperacion.NombreTarea}\n" +
                        $"Padre: {cooperacion.NombrePadre}\n" +
                        $"Alumno: {cooperacion.NombreAlumno}\n\n" +
                        $"Monto Total: ${cooperacion.Monto:F2}\n" +
                        $"Pagado: ${cooperacion.CantidadPagada:F2}\n" +
                        $"Restante: ${cooperacion.MontoRestante:F2}\n\n" +
                        $"Estado: {cooperacion.Estado?.ToUpper()}",
                        "Cooperación Seleccionada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
                else
                {
                    Debug.WriteLine($"DEBUG - No se encontró cooperación con idAsignacion: {idAsignacion}");
                    Debug.WriteLine($"DEBUG - Total cooperaciones cargadas: {_cooperacionesFiltradas?.Count ?? 0}");

                    MessageBox.Show(
                        $"No se encontró la cooperación solicitada (ID: {idAsignacion}).\n\n" +
                        "Posibles causas:\n" +
                        "• La cooperación fue eliminada\n" +
                        "• No existe en la base de datos\n" +
                        "• Los filtros están ocultándola\n\n" +
                        "Se mostrarán todas las cooperaciones disponibles.",
                        "Cooperación No Encontrada",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR - al seleccionar cooperación: {ex.Message}");
                Debug.WriteLine($"ERROR - StackTrace: {ex.StackTrace}");

                MessageBox.Show(
                    $"Error al buscar la cooperación:\n\n{ex.Message}",
                    "Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
        // Métodos de navegación del menú
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detallestareaWindow = new detallesTarea();
            detallestareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

    }
}
