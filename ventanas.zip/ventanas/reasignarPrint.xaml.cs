﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace eduTask.ventanas
{
    public partial class reasignarPrint : Window
    {
        private DataService _dataService;
        private List<padreResumen> _todosPadres;
        private padreResumen _padreSeleccionado;
        private AsignacionActual _asignacionActual;
        private List<TareaInfo> _todasTareas;
        private TareaInfo _nuevaTareaSeleccionada;

        public reasignarPrint()
        {
            InitializeComponent();
            _dataService = new DataService();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Cargar datos iniciales
            CargarPadres();

            // Manejar evento de focus en el TextBox
            txtBuscarPadre.GotFocus += (s, e) =>
            {
                if (txtBuscarPadre.Text == "Buscar por nombre, alumno o teléfono...")
                {
                    txtBuscarPadre.Text = "";
                }
            };

            txtBuscarPadre.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtBuscarPadre.Text))
                {
                    txtBuscarPadre.Text = "Buscar por nombre, alumno o teléfono...";
                }
            };
        }

        private void CargarPadres()
        {
            try
            {
                _todosPadres = _dataService.ObtenerTodosLosPadresResumen();
                dgPadres.ItemsSource = _todosPadres;

                if (_todosPadres.Count == 0)
                {
                    MessageBox.Show("No hay padres registrados en el sistema.",
                                  "Sin Padres",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar padres: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtBuscarPadre_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_todosPadres == null || _todosPadres.Count == 0)
                return;

            string textoBusqueda = txtBuscarPadre.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(textoBusqueda) ||
                textoBusqueda == "buscar por nombre, alumno o teléfono...")
            {
                dgPadres.ItemsSource = _todosPadres;
            }
            else
            {
                var padresFiltrados = _todosPadres.Where(p =>
                    (p.Nombre != null && p.Nombre.ToLower().Contains(textoBusqueda)) ||
                    (p.Alumno != null && p.Alumno.ToLower().Contains(textoBusqueda)) ||
                    (p.Telefono != null && p.Telefono.ToLower().Contains(textoBusqueda))
                ).ToList();

                dgPadres.ItemsSource = padresFiltrados;
            }
        }

        private void dgPadres_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgPadres.SelectedItem != null)
            {
                _padreSeleccionado = dgPadres.SelectedItem as padreResumen;

                if (_padreSeleccionado != null)
                {
                    // Cargar tarea actual del padre
                    CargarTareaActual();
                }
            }
            else
            {
                OcultarPaneles();
            }
        }

        private void CargarTareaActual()
        {
            try
            {
                _asignacionActual = _dataService.ObtenerAsignacionActualPadre(_padreSeleccionado.IdPadre);

                if (_asignacionActual != null)
                {
                    // Mostrar información de tarea actual
                    txtTareaActual.Text = $"Tarea: {_asignacionActual.TituloTarea}\n" +
                                         $"Tipo: {_asignacionActual.TipoTarea}\n" +
                                         $"Fecha Límite: {_asignacionActual.FechaLimite:dd/MM/yyyy}\n" +
                                         $"Estado: {_asignacionActual.Estado}\n" +
                                         $"Asignada el: {_asignacionActual.FechaAsignacion:dd/MM/yyyy}";

                    borderTareaActual.Visibility = Visibility.Visible;

                    // Mostrar panel de nueva tarea
                    gridNuevaTarea.Visibility = Visibility.Visible;
                    txtPadreSeleccionado.Text = $"(para {_padreSeleccionado.Nombre})";

                    // Cargar tareas disponibles
                    if (_todasTareas == null)
                    {
                        CargarTareas();
                    }
                }
                else
                {
                    MessageBox.Show("Este padre no tiene tareas asignadas actualmente.",
                                  "Sin Tarea Actual",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                    OcultarPaneles();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tarea actual: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CargarTareas()
        {
            try
            {
                _todasTareas = _dataService.ObtenerTodasLasTareasDetalladas();
                dgTareasDisponibles.ItemsSource = _todasTareas;

                if (_todasTareas.Count == 0)
                {
                    MessageBox.Show("No hay tareas disponibles para reasignar.",
                                  "Sin Tareas",
                                  MessageBoxButton.OK,
                                  MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dgTareasDisponibles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgTareasDisponibles.SelectedItem != null && _asignacionActual != null)
            {
                _nuevaTareaSeleccionada = dgTareasDisponibles.SelectedItem as TareaInfo;

                if (_nuevaTareaSeleccionada != null)
                {
                    // Verificar si es la misma tarea
                    if (_nuevaTareaSeleccionada.IdTarea == _asignacionActual.IdTarea)
                    {
                        MessageBox.Show("Ha seleccionado la misma tarea que tiene asignada actualmente.\n\n" +
                                      "Por favor seleccione una tarea diferente.",
                                      "Misma Tarea",
                                      MessageBoxButton.OK,
                                      MessageBoxImage.Warning);
                        dgTareasDisponibles.SelectedItem = null;
                        return;
                    }

                    MostrarResumen();
                }
            }
            else
            {
                gridResumen.Visibility = Visibility.Collapsed;
                btnReasignar.IsEnabled = false;
            }
        }

        private void MostrarResumen()
        {
            // Información del padre
            txtResumenPadre.Text = $"{_padreSeleccionado.Nombre}\n" +
                                  $"Alumno: {_padreSeleccionado.Alumno}";

            // Tarea actual
            txtResumenTareaActual.Text = $"{_asignacionActual.TituloTarea}\n" +
                                        $"Estado: {_asignacionActual.Estado}";

            // Nueva tarea
            txtResumenNuevaTarea.Text = $"{_nuevaTareaSeleccionada.Titulo}\n" +
                                       $"Tipo: {_nuevaTareaSeleccionada.Tipo}\n" +
                                       $"Límite: {_nuevaTareaSeleccionada.FechaLimite:dd/MM/yyyy}";

            // Mostrar resumen y habilitar botón
            gridResumen.Visibility = Visibility.Visible;
            btnReasignar.IsEnabled = true;
        }

        private void btnReasignar_Click(object sender, RoutedEventArgs e)
        {
            if (_padreSeleccionado == null || _asignacionActual == null || _nuevaTareaSeleccionada == null)
            {
                MessageBox.Show("No hay información suficiente para realizar la reasignación.",
                              "Datos Incompletos",
                              MessageBoxButton.OK,
                              MessageBoxImage.Warning);
                return;
            }

            string opcionEstado = rbManternerEstado.IsChecked == true
                ? "Se mantendrá el estado actual"
                : "Se reiniciará el estado a Pendiente";

            // Confirmar reasignación
            var resultado = MessageBox.Show(
                $"¿Está seguro de reasignar la tarea?\n\n" +
                $"Padre: {_padreSeleccionado.Nombre}\n\n" +
                $"Tarea Actual: {_asignacionActual.TituloTarea}\n" +
                $"   Estado: {_asignacionActual.Estado}\n\n" +
                $"   Nueva Tarea: {_nuevaTareaSeleccionada.Titulo}\n\n" +
                $"{opcionEstado}",
                "Confirmar Reasignación",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                RealizarReasignacion();
            }
        }

        private void RealizarReasignacion()
        {
            try
            {
                bool mantenerEstado = rbManternerEstado.IsChecked == true;

                bool reasignado = _dataService.ReasignarTarea(
                    _asignacionActual.IdAsignacion,
                    _nuevaTareaSeleccionada.IdTarea,
                    mantenerEstado);

                if (reasignado)
                {
                    MessageBox.Show("Tarea reasignada exitosamente.", "Éxito",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Limpiar y recargar
                    LimpiarFormulario();
                }
                else
                {
                    MessageBox.Show("No se pudo reasignar la tarea.", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al realizar la reasignación: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OcultarPaneles()
        {
            borderTareaActual.Visibility = Visibility.Collapsed;
            gridNuevaTarea.Visibility = Visibility.Collapsed;
            gridResumen.Visibility = Visibility.Collapsed;
            btnReasignar.IsEnabled = false;
        }

        private void LimpiarFormulario()
        {
            dgPadres.SelectedItem = null;
            dgTareasDisponibles.SelectedItem = null;
            txtBuscarPadre.Text = "Buscar por nombre, alumno o teléfono...";

            txtTareaActual.Text = string.Empty;
            txtResumenPadre.Text = string.Empty;
            txtResumenTareaActual.Text = string.Empty;
            txtResumenNuevaTarea.Text = string.Empty;

            OcultarPaneles();

            _padreSeleccionado = null;
            _asignacionActual = null;
            _nuevaTareaSeleccionada = null;

            // Recargar datos
            CargarPadres();
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
            menuWindow.Show();
            this.Close();
        }

        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agrerPadreWindow = new agrepaPrint();
            agrerPadreWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modpadresWindow = new modificarPadres();
            modpadresWindow.Show();
            this.Close();

        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }
        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }
        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}