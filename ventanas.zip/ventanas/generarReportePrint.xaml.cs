﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class generarReportePrint : Window
    {
        private DataService _dataService;
        private Padre _padreSeleccionado;
        private List<AsignacionCompleta> _tareasDelPadre;

        public generarReportePrint()
        {
            InitializeComponent();
            _dataService = new DataService();
            InicializarVentana();
        }

        private void InicializarVentana()
        {
            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Configurar TextBox de búsqueda
            ConfigurarPlaceholderTextBox(txtBuscarPadre, "Ingrese nombre del padre...");
        }

        private void ConfigurarPlaceholderTextBox(TextBox textBox, string placeholder)
        {
            textBox.GotFocus += (s, e) =>
            {
                if (textBox.Text == placeholder)
                {
                    textBox.Text = "";
                    textBox.Foreground = Brushes.Black;
                }
            };

            textBox.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = placeholder;
                    textBox.Foreground = Brushes.Gray;
                }
            };

            // Estado inicial
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.Foreground = Brushes.Gray;
            }
        }

        private void txtBuscarPadre_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Búsqueda en tiempo real deshabilitada por ahora
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            string textoBusqueda = txtBuscarPadre.Text.Trim();
            if (string.IsNullOrWhiteSpace(textoBusqueda) || textoBusqueda == "Ingrese nombre del padre...")
            {
                MessageBox.Show("Por favor ingrese un nombre para buscar.", "Búsqueda Vacía",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Buscar padres por nombre (coincidencia parcial)
                var padres = _dataService.BuscarPadresPorNombre(textoBusqueda);

                if (padres == null || padres.Count == 0)
                {
                    MessageBox.Show($"No se encontró ningún padre con el nombre: {textoBusqueda}",
                                  "Padre No Encontrado", MessageBoxButton.OK, MessageBoxImage.Information);
                    LimpiarInterfaz();
                    return;
                }

                Padre padreEncontrado;

                // Si hay múltiples resultados, mostrar para seleccionar
                if (padres.Count > 1)
                {
                    string opciones = "Se encontraron varios padres:\n\n";
                    for (int i = 0; i < padres.Count; i++)
                    {
                        opciones += $"{i + 1}. {padres[i].Nombre} - Alumno: {padres[i].Alumno ?? "N/A"}\n";
                    }
                    opciones += "\nSe seleccionará el primer resultado. Para mayor precisión, sea más específico.";

                    MessageBox.Show(opciones, "Múltiples Resultados",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Seleccionar el primero
                    padreEncontrado = padres[0];
                }
                else
                {
                    // Si solo hay un resultado, seleccionarlo directamente
                    padreEncontrado = padres[0];
                }

                _padreSeleccionado = padreEncontrado;

                // Mostrar información del padre
                MostrarInformacionPadre();

                // Cargar todas las tareas del padre (historial completo)
                CargarTareasDelPadre();

                // Calcular y mostrar cumplimiento
                CalcularCumplimiento();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al buscar padre: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void MostrarInformacionPadre()
        {
            if (_padreSeleccionado != null)
            {
                txtNombrePadre.Text = _padreSeleccionado.Nombre;
                txtNombreAlumno.Text = _padreSeleccionado.Alumno ?? "No especificado";
                borderInfoPadre.Visibility = Visibility.Visible;
            }
        }

        private void CargarTareasDelPadre()
        {
            if (_padreSeleccionado == null) return;

            try
            {
                // Obtener TODAS las asignaciones del padre (historial completo)
                _tareasDelPadre = _dataService.ObtenerAsignacionesCompletasPorPadre(_padreSeleccionado.IdPadre);

                if (_tareasDelPadre == null || _tareasDelPadre.Count == 0)
                {
                    dgTareasAsignadas.ItemsSource = null;
                    MessageBox.Show("El padre no tiene tareas asignadas en el historial.",
                                  "Sin Tareas", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                dgTareasAsignadas.ItemsSource = _tareasDelPadre;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CalcularCumplimiento()
        {
            if (_tareasDelPadre == null || _tareasDelPadre.Count == 0)
            {
                ActualizarInterfazCumplimiento(0, 0, 0);
                MostrarBotonesSegunCumplimiento(0);
                return;
            }

            int totalTareas = _tareasDelPadre.Count;
            int tareasCompletadas = _tareasDelPadre.Count(t =>
                t.Estado?.Equals("cumplida", StringComparison.OrdinalIgnoreCase) == true);

            double porcentajeCumplimiento = (double)tareasCompletadas / totalTareas * 100;

            ActualizarInterfazCumplimiento(porcentajeCumplimiento, totalTareas, tareasCompletadas);
            MostrarBotonesSegunCumplimiento(porcentajeCumplimiento);
        }

        private void ActualizarInterfazCumplimiento(double porcentaje, int totalTareas, int completadas)
        {
            // Actualizar barra de progreso
            double anchoBarra = 200 * (porcentaje / 100);
            borderProgreso.Width = Math.Max(0, Math.Min(200, anchoBarra));

            // Actualizar color de la barra según el porcentaje
            if (porcentaje >= 100)
                borderProgreso.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF4CAF50")); // Verde
            else if (porcentaje >= 70)
                borderProgreso.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFF9800")); // Naranja
            else
                borderProgreso.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF44336")); // Rojo

            // Actualizar texto de porcentaje
            txtPorcentaje.Text = $"{porcentaje:F1}%";

            // Actualizar estado
            string estado = porcentaje >= 100 ? " COMPLETADO" :
                           porcentaje >= 70 ? " REGULARIZABLE" :
                           " INSUFICIENTE";

            txtEstadoCumplimiento.Text = totalTareas > 0
                ? $"{estado} - {completadas}/{totalTareas} completadas"
                : "Sin tareas asignadas";
        }

        private void MostrarBotonesSegunCumplimiento(double porcentaje)
        {
            if (porcentaje >= 100)
            {
                btnGenerarReporte.Visibility = Visibility.Visible;
                btnRegularizar.Visibility = Visibility.Collapsed;
            }
            else if (porcentaje >= 70)
            {
                btnGenerarReporte.Visibility = Visibility.Collapsed;
                btnRegularizar.Visibility = Visibility.Visible;
            }
            else
            {
                btnGenerarReporte.Visibility = Visibility.Collapsed;
                btnRegularizar.Visibility = Visibility.Collapsed;

                if (porcentaje > 0)
                {
                    MessageBox.Show(
                        $"Cumplimiento insuficiente: {porcentaje:F1}%\n\n" +
                        "Requisitos:\n" +
                        "• 70% o más: Permite regularización\n" +
                        "• 100%: Permite generar vale de liberación",
                        "Cumplimiento Insuficiente",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                }
            }
        }

        private void btnRegularizar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_padreSeleccionado == null || _tareasDelPadre == null)
                {
                    MessageBox.Show("No hay un padre seleccionado.", "Sin Selección",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Buscar tareas
                var tareasPendientes = _tareasDelPadre
                    .Where(t => t.Estado?.Equals("incumplida", StringComparison.OrdinalIgnoreCase) == true)
                    .ToList();

                if (tareasPendientes.Count == 0)
                {
                    MessageBox.Show("No hay tareas pendientes para regularizar.",
                                  "Sin Tareas Pendientes",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // Crear y configurar el diálogo
                var dialog = new dialogoPrint();

                // Configurar propiedades ANTES de mostrar
                dialog.NombrePadre = _padreSeleccionado.Nombre ?? "Sin nombre";
                dialog.CantidadTareas = tareasPendientes.Count;

                // Mostrar diálogo
                dialog.Owner = this;
                dialog.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                bool? resultado = dialog.ShowDialog();

                if (resultado == true)
                {
                    // Obtener datos del diálogo
                    string tipoPenalizacion = dialog.TipoPenalizacionSeleccionada ?? "No especificada";
                    string descripcionPenalizacion = dialog.DescripcionPenalizacion ?? "";
                    bool penalizacionCumplida = dialog.PenalizacionCumplida;

                    // Mostrar confirmación detallada
                    string estadoPenalizacion = penalizacionCumplida ?
                        " CUMPLIDA (permitirá generar vale)" :
                        " PENDIENTE (debe cumplirse antes de generar vale)";

                    var confirmacion = MessageBox.Show(
                        $"¿Confirmar regularización de {tareasPendientes.Count} tarea(s)?\n\n" +
                        $" Padre: {_padreSeleccionado.Nombre}\n" +
                        $" Alumno: {_padreSeleccionado.Alumno ?? "No especificado"}\n\n" +
                        $" Tipo de penalización: {tipoPenalizacion}\n" +
                        $" Descripción: {descripcionPenalizacion}\n" +
                        $" Estado: {estadoPenalizacion}\n\n" +
                        "Esta acción marcará las tareas como completadas y registrará la penalización.",
                        "Confirmar Regularización",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (confirmacion == MessageBoxResult.Yes)
                    {
                        ProcesarRegularizacion(
                            tareasPendientes,
                            tipoPenalizacion,
                            descripcionPenalizacion,
                            penalizacionCumplida);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al iniciar regularización: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ProcesarRegularizacion(List<AsignacionCompleta> tareas, string tipoPenalizacion,
                                           string descripcion, bool penalizacionCumplida)
        {
            try
            {
                int tareasActualizadas = 0;
                int? idPenalizacion = null;
                string estadoTareas = penalizacionCumplida ? "cumplida" : "incumplida";
                string mensaje = "";

                // PASO 1: Verificar si ya existe una penalización PENDIENTE para este padre
                var penalizacionesPendientes = _dataService.ObtenerPenalizacionesPendientes(_padreSeleccionado.IdPadre);

                if (penalizacionesPendientes.Any() && !penalizacionCumplida)
                {
                    // Ya existe una penalización pendiente, no crear una nueva
                    var penalizacionExistente = penalizacionesPendientes.First();
                    idPenalizacion = penalizacionExistente.IdPenalizacion;

                    mensaje = $" Existe una penalización pendiente (ID: {idPenalizacion})\n" +
                             $"• Tipo: {penalizacionExistente.TipoPenalizacion}\n" +
                             $"• Asignada el: {penalizacionExistente.FechaAsignacion:dd/MM/yyyy}\n\n" +
                             $"No se creó una nueva penalización.";
                }
                else if (penalizacionCumplida && penalizacionesPendientes.Any())
                {
                    // Existe una penalización pendiente y ahora se marca como CUMPLIDA
                    var penalizacionExistente = penalizacionesPendientes.First();
                    idPenalizacion = penalizacionExistente.IdPenalizacion;

                    // ACTUALIZAR la penalización existente (no crear nueva)
                    bool actualizada = _dataService.ActualizarEstadoPenalizacion(idPenalizacion.Value, "cumplida");

                    if (actualizada)
                    {
                        mensaje = $" Penalización ACTUALIZADA como CUMPLIDA (ID: {idPenalizacion})\n" +
                                 $"• Tipo: {penalizacionExistente.TipoPenalizacion}\n" +
                                 $"• Cumplida el: {DateTime.Now:dd/MM/yyyy}";
                    }
                    else
                    {
                        mensaje = $" Error al actualizar la penalización existente";
                    }
                }
                else
                {
                    // No existe penalización pendiente o es primera vez
                    // CREAR una nueva penalización
                    idPenalizacion = _dataService.RegistrarPenalizacion(
                        _padreSeleccionado.IdPadre,
                        tipoPenalizacion,
                        descripcion,
                        DateTime.Now,
                        penalizacionCumplida ? "cumplida" : "incumplida");

                    if (idPenalizacion.HasValue && idPenalizacion.Value > 0)
                    {
                        mensaje = penalizacionCumplida
                            ? $" Nueva penalización registrada como CUMPLIDA (ID: {idPenalizacion})"
                            : $" Nueva penalización registrada como PENDIENTE (ID: {idPenalizacion})";
                    }
                    else
                    {
                        mensaje = $" Error al registrar la penalización";
                    }
                }

                // PASO 2: Actualizar estado de las tareas
                foreach (var tarea in tareas)
                {
                    string comentario = "";

                    if (idPenalizacion.HasValue)
                    {
                        comentario = penalizacionCumplida
                            ? $" Regularizada - Penalización CUMPLIDA (ID: {idPenalizacion}): {tipoPenalizacion}"
                            : $" Pendiente - Penalización ASIGNADA (ID: {idPenalizacion}): {tipoPenalizacion}";
                    }
                    else
                    {
                        comentario = penalizacionCumplida
                            ? $" Regularizada - Penalización CUMPLIDA: {tipoPenalizacion}"
                            : $" Pendiente - Penalización: {tipoPenalizacion}";
                    }

                    if (!string.IsNullOrEmpty(descripcion))
                    {
                        comentario += $" - {descripcion}";
                    }

                    bool actualizado = _dataService.ActualizarEstadoTarea(
                        tarea.IdAsignacion,
                        estadoTareas,
                        comentario);

                    if (actualizado) tareasActualizadas++;
                }

                // PASO 3: Mostrar resumen
                string resumenFinal = $"{mensaje}\n\n" +
                                    $" **ESTADO DE TAREAS**\n" +
                                    $"• Tareas procesadas: {tareasActualizadas} de {tareas.Count}\n" +
                                    $"• Estado: {(penalizacionCumplida ? "CUMPLIDAS " : "INCUMPLIDAS ")}\n\n";

                if (penalizacionCumplida)
                {
                    resumenFinal += "**Puede generar el vale de liberación ahora**";
                    MessageBox.Show(resumenFinal, " Regularización Completada",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    resumenFinal += " **La penalización está PENDIENTE**\n" +
                                  "• Debe cumplirla primero\n" +
                                  "• Luego marque 'Penalización cumplida'\n" +
                                  "• Finalmente podrá generar el vale";
                    MessageBox.Show(resumenFinal, " Penalización Asignada",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                // PASO 4: Recargar datos
                CargarTareasDelPadre();
                CalcularCumplimiento();
            }
            catch (Exception ex)
            {
                MessageBox.Show($" Error: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void btnGenerarReporte_Click(object sender, RoutedEventArgs e)
        {
            if (_padreSeleccionado == null || _tareasDelPadre == null)
            {
                MessageBox.Show("No hay información suficiente para generar el vale.",
                              "Datos Insuficientes",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                // Verificar tareas incompletas
                var tareasIncompletas = _tareasDelPadre
                    .Where(t => !t.Estado?.Equals("cumplida", StringComparison.OrdinalIgnoreCase) == true)
                    .ToList();

                if (tareasIncompletas.Count > 0)
                {
                    MessageBox.Show(
                        $" No se puede generar el vale.\n\n" +
                        $"Hay {tareasIncompletas.Count} tarea(s) incompleta(s).",
                        "Tareas Incompletas",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                // CORRECCIÓN: Verificar penalizaciones pendientes
                var penalizacionesPendientes = _dataService.ObtenerPenalizacionesPendientes(_padreSeleccionado.IdPadre);

                // Verificar si hay penalizaciones pendientes (lista no null y tiene elementos)
                if (penalizacionesPendientes != null && penalizacionesPendientes.Any())
                {
                    // Obtener información detallada de las penalizaciones pendientes
                    string infoPenalizaciones = "";
                    foreach (var penalizacion in penalizacionesPendientes.Take(3)) // Mostrar máximo 3
                    {
                        infoPenalizaciones += $"• {penalizacion.TipoPenalizacion}";
                        if (!string.IsNullOrEmpty(penalizacion.Descripcion))
                        {
                            infoPenalizaciones += $" - {penalizacion.Descripcion}";
                        }
                        infoPenalizaciones += $" (Asignada: {penalizacion.FechaAsignacion:dd/MM/yyyy})\n";
                    }

                    if (penalizacionesPendientes.Count > 3)
                    {
                        infoPenalizaciones += $"... y {penalizacionesPendientes.Count - 3} más\n";
                    }

                    MessageBox.Show(
                        $" No se puede generar el vale.\n\n" +
                        $"El padre tiene {penalizacionesPendientes.Count} penalización(es) PENDIENTE(s):\n\n" +
                        $"{infoPenalizaciones}\n" +
                        $"Debe cumplir todas las penalizaciones primero.",
                        "Penalizaciones Pendientes",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);
                    return;
                }

                // Si todo está en orden, mostrar ventana para generar vale
                MostrarVentanaGenerarVale();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al generar vale: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MostrarVentanaGenerarVale()
        {
            // Crear ventana de diálogo
            Window ventanaVale = new Window
            {
                Title = "Generar Vale de Liberación",
                Width = 600,
                Height = 750,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ResizeMode = ResizeMode.NoResize,
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFF8F8"))
            };

            Grid grid = new Grid();
            grid.Margin = new Thickness(25);

            // Definir filas
            for (int i = 0; i < 11; i++)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            }

            // Título
            TextBlock titulo = new TextBlock
            {
                Text = "Generar Vale de Liberación",
                FontSize = 16,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF2196F3")),
                Margin = new Thickness(0, 0, 0, 20),
                TextAlignment = TextAlignment.Center
            };
            Grid.SetRow(titulo, 0);
            grid.Children.Add(titulo);

            // Información del padre
            Border borderInfo = new Border
            {
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFE3F2FD")),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF2196F3")),
                BorderThickness = new Thickness(2),
                CornerRadius = new System.Windows.CornerRadius(8),
                Padding = new Thickness(15),
                Margin = new Thickness(0, 0, 0, 20)
            };

            StackPanel stackInfo = new StackPanel();

            // Nombre del padre
            StackPanel stackPadre = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            stackPadre.Children.Add(new TextBlock
            {
                Text = "Nombre del Padre:",
                FontSize = 10,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            });
            TextBox txtNombrePadreVale = new TextBox
            {
                Text = _padreSeleccionado.Nombre,
                FontSize = 10,
                Padding = new Thickness(8),
                BorderThickness = new Thickness(2),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF2196F3")),
                IsReadOnly = true,
                Background = Brushes.White
            };
            stackPadre.Children.Add(txtNombrePadreVale);
            stackInfo.Children.Add(stackPadre);

            // Nombre del alumno
            StackPanel stackAlumno = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            stackAlumno.Children.Add(new TextBlock
            {
                Text = "Nombre del Alumno:",
                FontSize = 10,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            });
            TextBox txtNombreAlumnoVale = new TextBox
            {
                Text = _padreSeleccionado.Alumno ?? "No especificado",
                FontSize = 10,
                Padding = new Thickness(8),
                BorderThickness = new Thickness(2),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF2196F3")),
                IsReadOnly = true,
                Background = Brushes.White
            };
            stackAlumno.Children.Add(txtNombreAlumnoVale);
            stackInfo.Children.Add(stackAlumno);

            // Fecha de generación
            StackPanel stackFecha = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
            stackFecha.Children.Add(new TextBlock
            {
                Text = "Fecha de Generación:",
                FontSize = 10,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            });
            TextBox txtFechaGeneracion = new TextBox
            {
                Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                FontSize = 10,
                Padding = new Thickness(8),
                BorderThickness = new Thickness(2),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF2196F3")),
                IsReadOnly = true,
                Background = Brushes.White
            };
            stackFecha.Children.Add(txtFechaGeneracion);
            stackInfo.Children.Add(stackFecha);

            // Código de liberación
            string codigoLiberacion = GenerarCodigoLiberacion();
            StackPanel stackCodigo = new StackPanel();
            stackCodigo.Children.Add(new TextBlock
            {
                Text = " Código de Liberación:",
                FontSize = 10,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            });
            TextBox txtCodigoLiberacion = new TextBox
            {
                Text = codigoLiberacion,
                FontSize = 10,
                FontWeight = FontWeights.Bold,
                Padding = new Thickness(8),
                BorderThickness = new Thickness(2),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF4CAF50")),
                IsReadOnly = true,
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFE8F5E9")),
                Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF4CAF50")),
                TextAlignment = TextAlignment.Center
            };
            stackCodigo.Children.Add(txtCodigoLiberacion);
            stackInfo.Children.Add(stackCodigo);

            borderInfo.Child = stackInfo;
            Grid.SetRow(borderInfo, 1);
            grid.Children.Add(borderInfo);

            // Sección de comentarios
            TextBlock lblComentarios = new TextBlock
            {
                Text = "Comentarios u Observaciones:",
                FontSize = 10,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 0, 0, 5)
            };
            Grid.SetRow(lblComentarios, 2);
            grid.Children.Add(lblComentarios);

            TextBox txtComentarios = new TextBox
            {
                FontSize = 10,
                Padding = new Thickness(8),
                BorderThickness = new Thickness(2),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF2196F3")),
                Height = 60,
                TextWrapping = TextWrapping.Wrap,
                AcceptsReturn = true,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Margin = new Thickness(0, 0, 0, 15)
            };
            Grid.SetRow(txtComentarios, 3);
            grid.Children.Add(txtComentarios);

            // Checkbox incluir tareas
            CheckBox chkIncluirTareas = new CheckBox
            {
                Content = "Incluir listado completo de tareas en el PDF",
                FontSize = 10,
                IsChecked = true,
                Margin = new Thickness(0, 0, 0, 20)
            };
            Grid.SetRow(chkIncluirTareas, 4);
            grid.Children.Add(chkIncluirTareas);

            // Resumen
            Border borderResumen = new Border
            {
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFEF5E7")),
                BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFF9800")),
                BorderThickness = new Thickness(2),
                CornerRadius = new System.Windows.CornerRadius(8),
                Padding = new Thickness(15),
                Margin = new Thickness(0, 0, 0, 20)
            };

            TextBlock txtResumen = new TextBlock
            {
                Text = $"Resumen:\n" +
                       $"• Total de tareas completadas: {_tareasDelPadre.Count}\n" +
                       $"• Porcentaje de cumplimiento: 100%\n" +
                       $"• Estado: APROBADO PARA LIBERACIÓN",
                FontSize = 10,
                LineHeight = 22
            };
            borderResumen.Child = txtResumen;
            Grid.SetRow(borderResumen, 5);
            grid.Children.Add(borderResumen);

            // Panel de botones
            StackPanel panelBotones = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 10, 0, 0)
            };

            Button btnGenerarPDF = new Button
            {
                Content = "GENERAR VALE PDF",
                Width = 180,
                Height = 45,
                Margin = new Thickness(0, 0, 15, 0),
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF4CAF50")),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                FontSize = 15,
                Cursor = System.Windows.Input.Cursors.Hand,
                BorderThickness = new Thickness(0)
            };

            Button btnCancelar = new Button
            {
                Content = "CANCELAR",
                Width = 150,
                Height = 45,
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FF6C757D")),
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                FontSize = 15,
                Cursor = System.Windows.Input.Cursors.Hand,
                BorderThickness = new Thickness(0)
            };

            btnGenerarPDF.Click += (s, ev) =>
            {
                var resultado = MessageBox.Show(
                    "¿Confirmar generación del Vale de Liberación?\n\n" +
                    "Esta acción creará un documento PDF oficial.",
                    "Confirmar Generación",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (resultado == MessageBoxResult.Yes)
                {
                    try
                    {
                        string comentarios = txtComentarios.Text.Trim();
                        bool incluirTareas = chkIncluirTareas.IsChecked == true;

                        // Generar vale en la base de datos
                        bool valeGenerado = _dataService.GenerarValeLiberacion(
                            _padreSeleccionado.IdPadre,
                            _padreSeleccionado.Nombre,
                            _padreSeleccionado.Alumno ?? "No especificado",
                            _tareasDelPadre.Count,
                            codigoLiberacion,
                            comentarios);

                        if (valeGenerado)
                        {
                            // Generar PDF
                            string rutaPDF = _dataService.GenerarPDFVale(
                                _padreSeleccionado.Nombre,
                                _padreSeleccionado.Alumno ?? "No especificado",
                                DateTime.Now,
                                codigoLiberacion,
                                _tareasDelPadre.Count,
                                comentarios,
                                incluirTareas ? _tareasDelPadre : null);

                            ventanaVale.Close();

                            if (!string.IsNullOrEmpty(rutaPDF))
                            {
                                var resultadoAbrir = MessageBox.Show(
                                    $"Vale de Liberación generado exitosamente.\n\n" +
                                    $"Archivo: {System.IO.Path.GetFileName(rutaPDF)}\n\n" +
                                    "¿Desea abrir el PDF?",
                                    "Vale Generado",
                                    MessageBoxButton.YesNo,
                                    MessageBoxImage.Information);

                                if (resultadoAbrir == MessageBoxResult.Yes)
                                {
                                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                                    {
                                        FileName = rutaPDF,
                                        UseShellExecute = true
                                    });
                                }
                            }

                            // Limpiar interfaz
                            LimpiarInterfaz();
                            txtBuscarPadre.Text = "Ingrese nombre del padre...";
                            txtBuscarPadre.Foreground = Brushes.Gray;
                        }
                        else
                        {
                            MessageBox.Show("No se pudo generar el vale de liberación.",
                                          "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error al generar vale: {ex.Message}", "Error",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            };

            btnCancelar.Click += (s, ev) => ventanaVale.Close();

            panelBotones.Children.Add(btnGenerarPDF);
            panelBotones.Children.Add(btnCancelar);

            Grid.SetRow(panelBotones, 6);
            grid.Children.Add(panelBotones);

            ventanaVale.Content = grid;
            ventanaVale.ShowDialog();
        }

        private string GenerarCodigoLiberacion()
        {
            // Generar código único basado en fecha y padre
            string fecha = DateTime.Now.ToString("yyyyMMddHHmmss");
            string random = new Random().Next(1000, 9999).ToString();
            return $"VL-{fecha}-{random}";
        }

        private void LimpiarInterfaz()
        {
            _padreSeleccionado = null;
            _tareasDelPadre = null;
            borderInfoPadre.Visibility = Visibility.Collapsed;
            dgTareasAsignadas.ItemsSource = null;
            btnGenerarReporte.Visibility = Visibility.Collapsed;
            btnRegularizar.Visibility = Visibility.Collapsed;
            borderProgreso.Width = 0;
            txtPorcentaje.Text = "0%";
            txtEstadoCumplimiento.Text = "Sin tareas asignadas";
            txtNombrePadre.Text = "-";
            txtNombreAlumno.Text = "-";
        }

        // Métodos de navegación del menú
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }

        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asignaAutoWindow = new asigAutomatica();
            asignaAutoWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asignaManualWindow = new asignacionManual();
            asignaManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detallesWindow = new detallesTarea();
            detallesWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCoopWindow = new detallesCooperacion();
            detallesCoopWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show(
                $"¿Está seguro que desea cerrar sesión?\n\nUsuario: {sesionGlobal.NombreMaestro}",
                "Cerrar Sesión",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}