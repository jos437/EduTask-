﻿using eduTask.baseDatos;
using eduTask.Utils;
using eduTask.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace eduTask.ventanas
{
    public partial class listadoTareas : Window
    {
        private DataService _dataService;
        private List<TareaAsignada> _todasAsignaciones;
        private List<TareaAsignada> _asignacionesFiltradas;

        public listadoTareas()
        {
            InitializeComponent();
            _dataService = new DataService();

            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            // Configurar TextBox de búsqueda
            txtBuscar.GotFocus += (s, e) =>
            {
                if (txtBuscar.Text == "Buscar por tarea, padre o alumno...")
                    txtBuscar.Text = "";
            };

            txtBuscar.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtBuscar.Text))
                    txtBuscar.Text = "Buscar por tarea, padre o alumno...";
            };

            // Cargar datos
            CargarDatos();
        }

        private void CargarDatos()
        {
            try
            {
                _todasAsignaciones = _dataService.ObtenerTodasLasAsignaciones();
                _asignacionesFiltradas = _todasAsignaciones;
                dgTareas.ItemsSource = _asignacionesFiltradas;

                ActualizarEstadisticas();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void txtBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            AplicarFiltros();
        }

        private void Filtros_Changed(object sender, SelectionChangedEventArgs e)
        {
            AplicarFiltros();
        }

        private void AplicarFiltros()
        {
            if (_todasAsignaciones == null || _todasAsignaciones.Count == 0)
                return;

            string textoBusqueda = txtBuscar.Text.Trim().ToLower();
            string filtroTipo = (cmbFiltroTipo.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Todos";
            string filtroEstado = (cmbFiltroEstado.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "Todos";

            _asignacionesFiltradas = _todasAsignaciones.Where(a =>
            {
                // Filtro de búsqueda
                bool cumpleBusqueda = string.IsNullOrWhiteSpace(textoBusqueda) ||
                                     textoBusqueda == "buscar por tarea, padre o alumno..." ||
                                     (a.NombreTarea != null && a.NombreTarea.ToLower().Contains(textoBusqueda)) ||
                                     (a.NombrePadre != null && a.NombrePadre.ToLower().Contains(textoBusqueda)) ||
                                     (a.NombreAlumno != null && a.NombreAlumno.ToLower().Contains(textoBusqueda));

                // Filtro de tipo
                bool cumpleTipo = filtroTipo == "Todos" ||
                                 (a.TipoTarea != null && a.TipoTarea.Equals(filtroTipo, StringComparison.OrdinalIgnoreCase));

                // Filtro de estado
                bool cumpleEstado = filtroEstado == "Todos" ||
                                   (a.Estado != null && a.Estado.Equals(filtroEstado.Replace("s", ""), StringComparison.OrdinalIgnoreCase));

                return cumpleBusqueda && cumpleTipo && cumpleEstado;
            }).ToList();

            dgTareas.ItemsSource = _asignacionesFiltradas;
            ActualizarEstadisticas();
        }

        private void ActualizarEstadisticas()
        {
            if (_asignacionesFiltradas == null)
                return;

            // Estadísticas generales
            int total = _asignacionesFiltradas.Count;
            int cumplidas = _asignacionesFiltradas.Count(a => a.Estado == "cumplida");
            int pendientes = _asignacionesFiltradas.Count(a => a.Estado == "pendiente");
            int incumplidas = _asignacionesFiltradas.Count(a => a.Estado == "incumplida");

            txtTotalTareas.Text = total.ToString();
            txtTareasCumplidas.Text = cumplidas.ToString();
            txtTareasPendientes.Text = pendientes.ToString();
            txtTareasIncumplidas.Text = incumplidas.ToString();

            // Estadísticas de cooperaciones
            var cooperaciones = _asignacionesFiltradas.Where(a =>
                a.TipoTarea != null &&
                a.TipoTarea.Equals("Cooperacion", StringComparison.OrdinalIgnoreCase));

            decimal totalRecaudar = cooperaciones.Sum(a => a.MontoCooperacion ?? 0);
            decimal recaudado = cooperaciones.Where(a => a.Estado == "cumplida").Sum(a => a.MontoCooperacion ?? 0);
            decimal falta = totalRecaudar - recaudado;

            txtTotalRecaudar.Text = $"${totalRecaudar:F2}";
            txtRecaudado.Text = $"${recaudado:F2}";
            txtFaltaRecaudar.Text = $"${falta:F2}";
        }

        private void btnLimpiarBusqueda_Click(object sender, RoutedEventArgs e)
        {
            txtBuscar.Text = "Buscar por tarea, padre o alumno...";
            cmbFiltroTipo.SelectedIndex = 0;
            cmbFiltroEstado.SelectedIndex = 0;
            AplicarFiltros();
        }

        private void btnVerDetalles_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag != null)
            {
                int idAsignacion = Convert.ToInt32(btn.Tag);

                detallesTarea detallesWindow = new detallesTarea(idAsignacion);
                detallesWindow.Show();
                this.Close();
            }
        }

        private void btnExportarTabla_Click(object sender, RoutedEventArgs e)
        {
            if (_asignacionesFiltradas == null || _asignacionesFiltradas.Count == 0)
            {
                MessageBox.Show("No hay datos para exportar.", "Sin Datos",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var saveDialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "Archivo Excel|*.xlsx",
                    FileName = $"Listado_Tareas_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                };

                if (saveDialog.ShowDialog() == true)
                {
                    bool exportado = _dataService.ExportarListadoTareas(_asignacionesFiltradas, saveDialog.FileName);

                    if (exportado)
                    {
                        var resultado = MessageBox.Show(
                            "Exportación completada exitosamente.\n\n" +
                            $"Archivo: {System.IO.Path.GetFileName(saveDialog.FileName)}\n\n" +
                            "¿Desea abrir el archivo?",
                            "Exportación Exitosa",
                            MessageBoxButton.YesNo,
                            MessageBoxImage.Information);

                        if (resultado == MessageBoxResult.Yes)
                        {
                            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                            {
                                FileName = saveDialog.FileName,
                                UseShellExecute = true
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al exportar: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAgregarTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        // Métodos de navegación del menú
        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint busquedaWindow = new busquedaPrint();
            busquedaWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }
    }
}