﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace eduTask.ventanas
{
    public partial class Inicio : Window
    {
        public Inicio()
        {
            InitializeComponent();
            Loaded += SplashScreen_Loaded;
        }

        private async void SplashScreen_Loaded(object sender, RoutedEventArgs e)
        {
            await InicializarAplicacion();
        }

        private async Task InicializarAplicacion()
        {
            try
            {
                // Paso 1: Cargar recursos
                await SimularCarga("Cargando recursos...", 100);
                await Task.Delay(500);

                // Paso 2: Conectar base de datos
                await SimularCarga("Conectando con la base de datos...", 200);
                await Task.Delay(500);

                // Paso 3: Verificar configuración
                await SimularCarga("Verificando configuración...", 280);
                await Task.Delay(500);

                // Paso 4: Preparar interfaz
                await SimularCarga("Preparando interfaz...", 350);
                await Task.Delay(500);

                // Paso 5: Completado
                await SimularCarga("¡Listo!", 350);
                await Task.Delay(300);

                // Abrir ventana de login
                Dispatcher.Invoke(() =>
                {
                    loginPrint loginWindow = new loginPrint();
                    loginWindow.Show();
                    this.Close();
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al inicializar la aplicación: {ex.Message}",
                              "Error de Inicio",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
                Application.Current.Shutdown();
            }
        }

        private async Task SimularCarga(string mensaje, double anchoFinal)
        {
            // Actualizar texto
            txtEstado.Text = mensaje;

            // Animar barra de progreso
            var animacion = new DoubleAnimation
            {
                To = anchoFinal,
                Duration = TimeSpan.FromMilliseconds(400),
                EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }
            };

            progressBar.BeginAnimation(WidthProperty, animacion);
            await Task.Delay(400);
        }
    }
}