﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class tareaPrint : Window
    {
        private DataService _dataService;

        public tareaPrint()
        {
            InitializeComponent();
            dpFechaRealizacion.SelectedDate = DateTime.Now;

            _dataService = new DataService();

            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            this.Loaded += (s, e) =>
            {
                dpFechaRealizacion.SelectedDate = DateTime.Now;
            };

        }

        private void cmbTipoTarea_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (gridCooperacion == null)
                return;

            if (cmbTipoTarea.SelectedItem != null)
            {
                string tipoSeleccionado = (cmbTipoTarea.SelectedItem as ComboBoxItem)?.Content.ToString();

                // Mostrar/ocultar campo de cooperación
                if (tipoSeleccionado == "cooperacion")
                {
                    gridCooperacion.Visibility = Visibility.Visible;
                }
                else
                {
                    gridCooperacion.Visibility = Visibility.Collapsed;
                    if (txtMontoCooperacion != null)
                    {
                        txtMontoCooperacion.Clear();
                    }
                }
            }
        }

        private void txtMontoCooperacion_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Validar que solo se ingresen números y punto decimal
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c) && c != '.')
                {
                    e.Handled = true;
                    return;
                }
            }

            // Validar que solo haya un punto decimal
            if (e.Text == "." && ((TextBox)sender).Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void btnCrear_Click(object sender, RoutedEventArgs e)
        {
            // Ocultar mensaje previo
            txtMensaje.Visibility = Visibility.Collapsed;

            // Validar título
            if (txtTitulo.Text == "Ingrese el nombre de la tarea" || string.IsNullOrWhiteSpace(txtTitulo.Text))
            {
                MessageBox.Show("El titulo de la tarea es obligatorio", "Validación",
                          MessageBoxButton.OK, MessageBoxImage.Warning);
                txtTitulo.Focus();
                return;
            }

            // Validar fecha
            if (!dpFechaRealizacion.SelectedDate.HasValue)
            {
                MessageBox.Show("Debe de seleccionar una fecha válida", "Error",
                                              MessageBoxButton.OK, MessageBoxImage.Error);
                dpFechaRealizacion.Focus();
                return;
            }

            // Validar que la fecha no sea anterior a hoy
            if (dpFechaRealizacion.SelectedDate.Value < DateTime.Now.Date)
            {
                MessageBox.Show("La fecha no debe de ser anterior a la fecha de hoy", "Error",
                                              MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Validar tipo de tarea
            if (cmbTipoTarea.SelectedItem == null)
            {
                MessageBox.Show("Debe de seleccionar un tipo de tarea", "Error",
                                              MessageBoxButton.OK, MessageBoxImage.Error);
                cmbTipoTarea.Focus();
                return;
            }

            // Obtener datos del formulario
            string titulo = txtTitulo.Text.Trim();
            string descripcion = txtDescripcion.Text.Trim();
            DateTime fechaRealizacion = dpFechaRealizacion.SelectedDate.Value;
            string tipoTarea = (cmbTipoTarea.SelectedItem as ComboBoxItem)?.Content.ToString();

            decimal? montoCooperacion = null;

            // Si es cooperación, obtener el monto
            if (tipoTarea == "cooperacion" && !string.IsNullOrWhiteSpace(txtMontoCooperacion.Text))
            {
                if (decimal.TryParse(txtMontoCooperacion.Text, out decimal monto))
                {
                        montoCooperacion = monto;
                        Debug.WriteLine($"DEBUG btnCrear - Monto capturado: {montoCooperacion}"); // ← AGREGAR ESTO
                    }
                    else
                    {
                    MessageBox.Show("El monto de cooperación debe de ser un número válido", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                    txtMontoCooperacion.Focus();
                    return;
                }
            }

            if (tipoTarea == "cooperacion" && !montoCooperacion.HasValue)
            {
                MessageBox.Show("Debe ingresar un monto para la cooperación", "Validación",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                txtMontoCooperacion.Focus();
                return;
            }

            Debug.WriteLine($"DEBUG btnCrear - Enviando monto: {montoCooperacion}"); // ← AGREGAR ESTO

            bool exito = _dataService.GuardarTarea(titulo, descripcion, fechaRealizacion,
                                                  tipoTarea, sesionGlobal.IdMaestro, montoCooperacion);
            if (exito)
            {
                LimpiarFormulario();
            }
        }
        

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cancelar? Los cambios no guardados se perderán.",
                                          "Confirmar Cancelación",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
                menuWindow.Show();
                this.Close();
            }
        }

        private void LimpiarFormulario()
        {
            txtTitulo.Text = "Ingrese el nombre de la tarea";
            txtTitulo.Foreground = Brushes.Gray;

            txtDescripcion.Text = "Ingrese datos relevantes (hora, lugar, material a traer, acciones a realizar)";
            txtDescripcion.Foreground = Brushes.Gray;

            dpFechaRealizacion.SelectedDate = DateTime.Now;
            cmbTipoTarea.SelectedIndex = 0;

            if (txtMontoCooperacion != null)
            {
                txtMontoCooperacion.Clear();
            }

            if (gridCooperacion != null)
            {
                gridCooperacion.Visibility = Visibility.Collapsed;
            }

            txtMensaje.Visibility = Visibility.Collapsed;

        }

        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void  eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            eliTareaPrint eliminartareaWindow = new eliTareaPrint();
            eliminartareaWindow.Show();
            this.Close();
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modificartareaWindow = new modiTareaPrint();
            modificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                // Restaurar el placeholder según el TextBox
                if (textBox.Name == "txtTitulo")
                    textBox.Text = "Ingrese el nombre de la tarea";
                else if (textBox.Name == "txtDescripcion")
                    textBox.Text = "Ingrese datos relevantes (hora, lugar, material a traer, acciones a realizar)";
                textBox.Foreground = Brushes.Gray;
            }
        }

    }
}