﻿using eduTask.baseDatos;
using eduTask.Modelos;
using eduTask.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace eduTask.ventanas
{
    public partial class eliTareaPrint : Window
    {
        private DataService _dataService;
        private List<TareaInfo> _todasLasTareas;
        private TareaInfo _tareaSeleccionada;

        public eliTareaPrint()
        {
            InitializeComponent();
            _dataService = new DataService();
            ConfigurarPlaceholders();


            // Verificar sesión activa
            if (!sesionGlobal.ValidarSesion())
            {
                MessageBox.Show("No hay una sesión activa. Por favor inicie sesión nuevamente.",
                              "Sesión Inválida", MessageBoxButton.OK, MessageBoxImage.Warning);
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
                return;
            }

            CargarTareas();
        }
        private void ConfigurarPlaceholders()
        {
            txtBuscarTarea.Text = "Ingrese nombre a buscar";
            txtBuscarTarea.Foreground = Brushes.Gray;
        }
        private void CargarTareas()
        {
            try
            {
                _todasLasTareas = _dataService.ObtenerTodasLasTareasDetalladas();
                dgTareas.ItemsSource = _todasLasTareas;

                if (_todasLasTareas.Count == 0)
                {
                    MessageBox.Show("No hay tareas registradas en el sistema.", "Sin Tareas",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar las tareas: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnBuscar_Click(object sender, RoutedEventArgs e)
        {
            BuscarTareas();
        }

        private void txtBuscarTarea_TextChanged(object sender, TextChangedEventArgs e)
        {
            BuscarTareas();
        }

        private void BuscarTareas()
        {
            if (_todasLasTareas == null || _todasLasTareas.Count == 0)
                return;

            string textoBusqueda = txtBuscarTarea.Text.Trim().ToLower();

            if (string.IsNullOrWhiteSpace(textoBusqueda))
            {
                // Mostrar todas las tareas
                dgTareas.ItemsSource = _todasLasTareas;
            }
            else
            {
                // Filtrar tareas
                var tareasFiltradas = _todasLasTareas.Where(t =>
                    (t.Titulo != null && t.Titulo.ToLower().Contains(textoBusqueda)) ||
                    (t.Descripcion != null && t.Descripcion.ToLower().Contains(textoBusqueda)) ||
                    (t.Tipo != null && t.Tipo.ToLower().Contains(textoBusqueda))
                ).ToList();

                dgTareas.ItemsSource = tareasFiltradas;

                if (tareasFiltradas.Count == 0)
                {
                    MessageBox.Show("No se encontraron tareas que coincidan con la búsqueda.",
                                  "Sin Resultados", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void dgTareas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgTareas.SelectedItem != null)
            {
                _tareaSeleccionada = dgTareas.SelectedItem as TareaInfo;

                if (_tareaSeleccionada != null)
                {
                    MostrarInformacionTarea(_tareaSeleccionada);
                    btnEliminar.IsEnabled = true;
                }
            }
            else
            {
                OcultarInformacionTarea();
                btnEliminar.IsEnabled = false;
            }
        }

        private void MostrarInformacionTarea(TareaInfo tarea)
        {
            txtInfoTarea.Text = $"ID: {tarea.IdTarea}\n" +
                               $"Título: {tarea.Titulo ?? "Sin título"}\n" +
                               $"Descripción: {tarea.Descripcion ?? "Sin descripción"}\n" +
                               $"Tipo: {tarea.Tipo}\n" +
                               $"Fecha de Creación: {tarea.FechaCreacion:dd/MM/yyyy}\n" +
                               $"Veces Asignada: {tarea.VecesAsignada}";

            borderInfoTarea.Visibility = Visibility.Visible;
        }

        private void OcultarInformacionTarea()
        {
            txtInfoTarea.Text = string.Empty;
            borderInfoTarea.Visibility = Visibility.Collapsed;
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            if (_tareaSeleccionada == null)
            {
                MessageBox.Show("Por favor seleccione una tarea para eliminar.", "Tarea no Seleccionada",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Obtener estadísticas de la tarea
            string estadisticas = _dataService.ObtenerEstadisticasTarea(_tareaSeleccionada.IdTarea);

            // Verificar si tiene asignaciones activas
            bool tieneAsignacionesActivas = _dataService.TareaTieneAsignacionesActivas(_tareaSeleccionada.IdTarea);

            string mensajeAdvertencia = tieneAsignacionesActivas
                ? "\n\nADVERTENCIA: Esta tarea tiene asignaciones activas (Pendientes o En Proceso)."
                : "";

            // Confirmar eliminación
            var resultado = MessageBox.Show(
                $"¿Está seguro que desea eliminar la siguiente tarea?\n\n" +
                $"ID: {_tareaSeleccionada.IdTarea}\n" +
                $"Título: {_tareaSeleccionada.Titulo}\n" +
                $"Tipo: {_tareaSeleccionada.Tipo}\n\n" +
                $"{mensajeAdvertencia}\n\n" +
                $"ESTA ACCIÓN NO SE PUEDE DESHACER",
                "Confirmar Eliminación",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (resultado == MessageBoxResult.Yes)
            {
                EliminarTarea(_tareaSeleccionada.IdTarea);
            }
        }
        private void EliminarTarea(int idTarea)
        {
            try
            {
                bool eliminado = _dataService.EliminarTarea(idTarea);

                if (eliminado)
                {
                    MessageBox.Show("Tarea eliminada exitosamente.", "Éxito",
                                  MessageBoxButton.OK, MessageBoxImage.Information);

                    // Limpiar selección
                    dgTareas.SelectedItem = null;
                    OcultarInformacionTarea();
                    txtBuscarTarea.Clear();

                    // Recargar lista
                    CargarTareas();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar la tarea.", "Error",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar la tarea: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cancelar?",
                                          "Confirmar Cancelación",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                MenuPrint menuWindow = new MenuPrint(sesionGlobal.UsuarioActual);
                menuWindow.Show();
                this.Close();
            }
        }

        private void agregarPadre_Click(object sender, RoutedEventArgs e)
        {
            agrepaPrint agregarWindow = new agrepaPrint();
            agregarWindow.Show();
            this.Close();
        }

        private void modificarPadres_Click(object sender, RoutedEventArgs e)
        {
            modificarPadres modificarWindow = new modificarPadres();
            modificarWindow.Show();
            this.Close();
        }

        private void buscarPadres_Click(object sender, RoutedEventArgs e)
        {
            busquedaPrint buscarWindow = new busquedaPrint();
            buscarWindow.Show();
            this.Close();
        }

        private void eliminarPadres_Click(object sender, RoutedEventArgs e)
        {
            eliminarPrint eliminarWindow = new eliminarPrint();
            eliminarWindow.Show();
            this.Close();
        }

        private void exportarListas_Click(object sender, RoutedEventArgs e)
        {
            exportarPrint exportarWindow = new exportarPrint();
            exportarWindow.Show();
            this.Close();
        }

        private void crearTarea_Click(object sender, RoutedEventArgs e)
        {
            tareaPrint tareaWindow = new tareaPrint();
            tareaWindow.Show();
            this.Close();
        }

        private void eliminarTarea_Click(object sender, RoutedEventArgs e)
        {
            //ventana actual
        }

        private void modificarTarea_Click(object sender, RoutedEventArgs e)
        {
            modiTareaPrint modifificartareaWindow = new modiTareaPrint();
            modifificartareaWindow.Show();
            this.Close();
        }
        private void asignaAutomatica_Click(object sender, RoutedEventArgs e)
        {
            asigAutomatica asigAutomaticaWindow = new asigAutomatica();
            asigAutomaticaWindow.Show();
            this.Close();
        }

        private void asignaManual_Click(object sender, RoutedEventArgs e)
        {
            asignacionManual asigManualWindow = new asignacionManual();
            asigManualWindow.Show();
            this.Close();
        }

        private void reasignaTareas_Click(object sender, RoutedEventArgs e)
        {
            reasignarPrint reasignarWindow = new reasignarPrint();
            reasignarWindow.Show();
            this.Close();
        }

        private void listadoActivi_Click(object sender, RoutedEventArgs e)
        {
            listadoTareas listadoWindow = new listadoTareas();
            listadoWindow.Show();
            this.Close();
        }

        private void detallesTareas_Click(object sender, RoutedEventArgs e)
        {
            detallesTarea detalleTareaWindow = new detallesTarea();
            detalleTareaWindow.Show();
            this.Close();
        }

        private void detallesCoopera_Click(object sender, RoutedEventArgs e)
        {
            detallesCooperacion detallesCooperacionWindow = new detallesCooperacion();
            detallesCooperacionWindow.Show();
            this.Close();
        }

        private void generarVale_Click(object sender, RoutedEventArgs e)
        {
            generarReportePrint generarWindow = new generarReportePrint();
            generarWindow.Show();
            this.Close();
        }

        private void cerrarSesion_Click(object sender, RoutedEventArgs e)
        {
            var resultado = MessageBox.Show("¿Está seguro que desea cerrar sesión?",
                                          "Cerrar Sesión",
                                          MessageBoxButton.YesNo,
                                          MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                sesionGlobal.CerrarSesion();
                loginPrint loginWindow = new loginPrint();
                loginWindow.Show();
                this.Close();
            }
        }

        // Métodos de placeholder
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Foreground == Brushes.Gray)
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = "Ingrese el nombre de la tarea a buscar";
                textBox.Foreground = Brushes.Gray;
            }
        }
    }
}